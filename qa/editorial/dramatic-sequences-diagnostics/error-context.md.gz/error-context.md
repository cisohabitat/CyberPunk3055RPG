# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: dramatic-sequences.spec.ts >> sequence edda-request: missing art retains description and actions
- Location: tests/dramatic-sequences.spec.ts:22:50

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  getByTestId('scene-illustration')
Expected: "true"
Received: "false"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" getByTestId('scene-illustration') with timeout 5000ms
  - waiting for getByTestId('scene-illustration')
    13 × locator resolved to <figure data-layout="paired" data-reading="false" data-unavailable="false" class="scene-illustration" data-testid="scene-illustration">…</figure>
       - unexpected value "false"

```

```yaml
- 'figure "Helion · before a name goes on the request View artwork: Helion · before a name goes on the request"':
  - img "Edda pauses with a pencil above a blank unsigned request sheet, her other hand open beside it. The closed ledger stays separate under the archive lamp."
  - text: Helion · before a name goes on the request
  - 'button "View artwork: Helion · before a name goes on the request"': View artwork
```

# Test source

```ts
  1  | import {test,expect,type Page}from '@playwright/test';
  2  | import AxeBuilder from '@axe-core/playwright';
  3  | import {SEQUENCE_CHECKPOINTS}from '../qa/production/dramatic-sequences-checkpoints';
  4  | import {getScene,sceneText,presentChoices,commitChoice}from '../lib/engine';
  5  | import {visibleCampaignDialogue}from '../lib/campaign-dialogue';
  6  | import {installAudioReview,type AudioReview}from '../qa/production/audio-review';
  7  | import type{GameState}from '../lib/types';
  8  | async function open(page:Page,state:GameState,width:number,artwork='full',sound=false){
  9  |  await page.setViewportSize({width,height:900});await page.addInitScript(({state,artwork,sound})=>{if(!localStorage.getItem('saint-shard-3055-v1'))localStorage.setItem('saint-shard-3055-v1',JSON.stringify(state));localStorage.setItem('saint-shard-preferences',JSON.stringify({artwork,sound,autoVoices:sound,voices:100,reading:'all',textStep:2,contrast:'high',motion:'reduce'}));},{state,artwork,sound});await page.goto('/');await page.getByTestId('continue-run').click();await expect(page.getByTestId('goal')).toBeVisible();
  10 | }
  11 | const saved=(p:Page)=>p.evaluate(()=>localStorage.getItem('saint-shard-3055-v1'));
  12 | for(const width of [320,390,1440])for(const{rule,state}of SEQUENCE_CHECKPOINTS)test(`sequence ${rule.id}: enlarged full scene, paired art and legal exit at ${width}`,async({page},info)=>{
  13 |  await open(page,state,width);const before=await saved(page);await expect(page.getByTestId('scene-text')).toHaveText(sceneText(getScene(state.sceneId),state).split(/\n\n+/).filter(Boolean).join(''));
  14 |  const figure=page.getByTestId('scene-illustration'),im=figure.locator('img');await expect(im).toHaveAttribute('src',rule.illustration.src);await expect(im).toHaveAttribute('alt',rule.illustration.description);await im.scrollIntoViewIfNeeded();await expect(im.locator('xpath=..')).toHaveAttribute('data-ready','true');await im.evaluate((im:HTMLImageElement)=>im.decode());await expect(figure).toContainText(rule.illustration.caption);
  15 |  await figure.getByRole('button',{name:/View artwork/}).click();const modal=page.getByRole('dialog');await expect(modal).toBeVisible();await expect(modal.locator('img')).toHaveAttribute('src',rule.illustration.src);await page.keyboard.press('Escape');await expect(modal).toHaveCount(0);
  16 |  expect((await new AxeBuilder({page}).analyze()).violations).toEqual([]);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);expect(await saved(page)).toEqual(before);await page.screenshot({path:info.outputPath('scene.png'),fullPage:true});
  17 |  await page.reload();await page.getByTestId('continue-run').click();expect(await saved(page)).toEqual(before);const c=presentChoices(state,getScene(state.sceneId)).find(c=>c.enabled&&!c.check)!;await page.getByTestId('choice-'+c.id).click();await expect.poll(async()=>JSON.parse((await saved(page))!)).toEqual(commitChoice(state,c).state);
  18 | });
  19 | for(const{rule,state}of SEQUENCE_CHECKPOINTS)test(`sequence ${rule.id}: text-only makes no art requests`,async({page})=>{
  20 |  const art:string[]=[];page.on('request',r=>{if(new URL(r.url()).pathname.startsWith('/art/'))art.push(r.url());});await open(page,state,320,'none');await expect(page.getByTestId('scene-illustration')).toHaveCount(0);await expect(page.getByTestId('scene-text')).toContainText(sceneText(getScene(state.sceneId),state).split('\n\n')[0]);expect(art).toEqual([]);
  21 | });
  22 | for(const{rule,state}of SEQUENCE_CHECKPOINTS)test(`sequence ${rule.id}: missing art retains description and actions`,async({page})=>{
> 23 |  await page.route('**/art/sequence-*',r=>r.abort());await open(page,state,390);await expect(page.getByTestId('scene-illustration')).toHaveAttribute('data-unavailable','true');await expect(page.getByTestId('scene-illustration')).toContainText(rule.illustration.description);await expect(page.getByTestId('scene-text')).toContainText(sceneText(getScene(state.sceneId),state).split('\n\n')[0]);
     |                                                                                                                                     ^ Error: expect(locator).toHaveAttribute(expected) failed
  24 | });
  25 | for(const{rule,state}of SEQUENCE_CHECKPOINTS)test(`sequence ${rule.id}: exact existing voice and actor finish naturally`,async({page})=>{
  26 |  await page.addInitScript(installAudioReview,{});await open(page,state,390,'full',true);const before=await saved(page);const lines=visibleCampaignDialogue(state.sceneId,getScene(state.sceneId).speaker,sceneText(getScene(state.sceneId),state));expect(lines.length).toBeGreaterThan(0);const audio=()=>page.evaluate(()=>(window as unknown as{audioReview:AudioReview}).audioReview);
  27 |  for(const line of lines){const file=line.id+(line.id.startsWith('voice-campaign-')?'.mp3':'.wav');await expect.poll(async()=>(await audio()).disposed,{timeout:20000}).toContain(file);expect(line.speaker).toBe(rule.actor);}
  28 |  expect(await saved(page)).toEqual(before);expect((await audio()).started.filter(f=>f.startsWith('voice-'))).toEqual(lines.map(l=>l.id+(l.id.startsWith('voice-campaign-')?'.mp3':'.wav')));
  29 | });
  30 | 
```