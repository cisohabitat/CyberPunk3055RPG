# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scene-performance.spec.ts >> scene performance voice-campaign-kerr-899d4ba5ecfb: replay retains cached original level
- Location: tests/scene-performance.spec.ts:38:60

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 2
+ Received  + 2

  Array [
-   0.66834392,
-   0.66834392,
+   0.6683439016342163,
+   0.6683439016342163,
  ]
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - link "Skip to choices" [ref=e4]:
      - /url: "#choices"
    - banner [ref=e5]:
      - generic [ref=e12]:
        - text: Saint Shard
        - generic [ref=e13]: Kite City 3055
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Strain
          - meter "Strain 0 of 5" [ref=e19]
        - generic [ref=e25]: 165 cr
      - generic [ref=e28]:
        - button "Settings" [ref=e29] [cursor=pointer]
        - button "Saves" [ref=e30] [cursor=pointer]
        - button "Sheet" [ref=e31] [cursor=pointer]
        - button "Abandon" [ref=e32] [cursor=pointer]
    - main [ref=e34]:
      - article [ref=e35]:
        - generic [ref=e36]:
          - figure [ref=e37]:
            - generic "Kerr · Her shadow" [ref=e38]:
              - generic [ref=e39]: Kerr
              - generic [ref=e40]: Her shadow
          - generic [ref=e41]:
            - paragraph [ref=e42]:
              - text: Ward Four stall
              - generic [ref=e46]: · The Week
            - heading "Ward Four stall · The Week" [level=1] [ref=e47]
            - paragraph [ref=e48]: The week wants a buyer or a witness.
            - paragraph [ref=e49]: Ward Four stall · The Week. The week wants a buyer or a witness.
        - status [ref=e50]: Loaded Autosave — The Week · Ward Four stall
        - generic [ref=e51]:
          - paragraph [ref=e52]: “You showed me the source summary. Leave the witness out of my errands. I don't need a person's address to ask about a shift.”
          - paragraph [ref=e53]: “My name went into their register after you promised it wouldn't. Say that before you ask me for another introduction.”
          - paragraph [ref=e54]: The counter offers registered sorting work under your own handle. An introduction supplies no payment, recovery, treatment or source. Any earlier breach stays recorded.
        - complementary "Kerr selected dialogue" [ref=e55]:
          - button "Listen to Kerr" [active] [ref=e56] [cursor=pointer]
          - button "Play all dialogue" [ref=e57] [cursor=pointer]
          - status [ref=e58]: Selected dialogue · Line 1 of 2 · synthetic voice
          - group [ref=e62]:
            - generic "Voice transcript" [ref=e63] [cursor=pointer]
            - list [ref=e64]:
              - listitem [ref=e65]:
                - strong [ref=e66]: "Kerr:"
                - text: You showed me the source summary. Leave the witness out of my errands. I don't need a person's address to ask about a shift.
              - listitem [ref=e67]:
                - strong [ref=e68]: "Kerr:"
                - text: My name went into their register after you promised it wouldn't. Say that before you ask me for another introduction.
            - generic [ref=e69]:
              - generic [ref=e70]: Dialogue line
              - combobox "Dialogue line" [ref=e71]:
                - option "1. Kerr · You showed me the source summary. Leave the witness out of my er" [selected]
                - option "2. Kerr · My name went into their register after you promised it wouldn't."
        - region "Current commitments" [ref=e73]:
          - group [ref=e74]:
            - generic "Campaign commitments · 1/2 complete · 1 compromised" [ref=e75] [cursor=pointer]
        - group [ref=e76]:
          - generic "Depot response · people and consequences" [ref=e77] [cursor=pointer]
        - region [ref=e78]:
          - generic [ref=e79]:
            - heading "Your next move" [level=2] [ref=e80]
            - paragraph [ref=e81]: Selecting an option commits it. For a check, review the odds and costs first; Back leaves it unrolled.
            - paragraph [ref=e82]:
              - generic [ref=e83]: Action
              - generic [ref=e86]: Move on
          - button "Acknowledge the broken private terms and retain the docket." [ref=e89] [cursor=pointer]:
            - generic [ref=e90]: "1"
          - button "Deny the recorded breach. Kerr withholds this introduction." [ref=e95] [cursor=pointer]:
            - generic [ref=e96]: "2"
          - button "Leave the conversation with the actual terms unchanged." [ref=e101] [cursor=pointer]:
            - generic [ref=e102]: "3"
        - group [ref=e107]:
          - generic "Look closer · Kerr's counter · his answer" [ref=e108] [cursor=pointer]
```

# Test source

```ts
  1  | import {test,expect,type Page}from '@playwright/test';
  2  | import {SCENE_PERFORMANCE_CHECKPOINTS}from '../qa/production/scene-performance-checkpoints';
  3  | import {getScene,sceneText,presentChoices,commitChoice}from '../lib/engine';
  4  | import {performanceVoicePath}from '../lib/performance-delivery';
  5  | import {voiceLevel}from '../lib/voice-level';
  6  | import {scenePerformanceLevel}from '../lib/scene-performance';
  7  | import {sceneIllustration}from '../lib/art';
  8  | import {installAudioReview,type AudioReview}from '../qa/production/audio-review';
  9  | import type{GameState}from '../lib/types';
  10 | const audio=(p:Page)=>p.evaluate(()=>(window as unknown as{audioReview:AudioReview}).audioReview);
  11 | const saved=(p:Page)=>p.evaluate(()=>localStorage.getItem('saint-shard-3055-v1'));
  12 | const cases=SCENE_PERFORMANCE_CHECKPOINTS;
  13 | const file=(id:string)=>id+(id.startsWith('voice-campaign-')?'.mp3':'.wav');
  14 | async function open(p:Page,state:GameState,{width=390,automatic=true,sound=true,voices=70,paragraph=false}={}){
  15 |  await p.setViewportSize({width,height:900});await p.addInitScript(installAudioReview,{});await p.addInitScript(({state,automatic,sound,voices,paragraph})=>{localStorage.setItem('saint-shard-3055-v1',JSON.stringify(state));localStorage.setItem('saint-shard-preferences',JSON.stringify({sound,voices,autoVoices:automatic,music:60,ambience:50,effects:0,reading:paragraph?'paragraph':'all',artwork:paragraph?'none':'full',textStep:2,motion:'reduce'}));},{state,automatic,sound,voices,paragraph});await p.goto('/');await p.getByTestId('continue-run').click();await expect(p.getByTestId('goal')).toBeVisible();
  16 | }
  17 | function requests(p:Page){const paths:string[]=[];p.on('request',r=>{const path=new URL(r.url()).pathname;if(path.includes('/voice-'))paths.push(path);});return paths;}
  18 | async function manual(p:Page,c:typeof cases[number]){const v=p.getByTestId('voice-line');await v.locator('summary').click();if(c.lines.length>1)await v.getByLabel('Dialogue line',{exact:true}).selectOption(c.lines.find(l=>l.id===c.delivery.id)!.key);await v.getByRole('button',{name:'Listen to '+c.delivery.speaker,exact:true}).click();return v;}
  19 | async function cleanup(p:Page){await p.evaluate(()=>window.dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true})));await expect.poll(async()=>(await audio(p)).liveSources).toBe(0);const a=await audio(p);expect(a.sourcesCreated).toBe(a.sourcesDisposed);expect(a.sourcesCreated).toBe(a.buffersCleared);}
  20 | for(const width of[390,1440])for(const c of cases)test(`scene performance ${c.delivery.id}: complete words, actor, art and natural queue at${width}`,async({page})=>{
  21 |  const paths=requests(page);await open(page,c.state,{width});const before=await saved(page);await expect(page.getByTestId('scene-text')).toHaveText(sceneText(getScene(c.state.sceneId),c.state).split(/\n\n+/).filter(Boolean).join(''));
  22 |  for(const l of c.lines){await expect(page.getByTestId('spoken-quote')).toContainText(l.text);await expect(page.getByTestId('spoken-quote')).toHaveAttribute('data-speaker',l.speaker);await expect.poll(async()=>(await audio(page)).disposed,{timeout:20000}).toContain(file(l.id));}
  23 |  const a=await audio(page);expect(a.started.filter(f=>f.startsWith('voice-'))).toEqual(c.lines.map(l=>file(l.id)));expect(paths).toEqual(c.lines.map(l=>performanceVoicePath(l.id)??'/audio/'+file(l.id)));for(const l of c.lines){const path=performanceVoicePath(l.id)??'/audio/'+file(l.id);expect(a.voiceLevels.find(r=>r.file===file(l.id))!.gain).toBeCloseTo(scenePerformanceLevel(l.id,path)??voiceLevel(l.id),6);}
  24 |  const art=sceneIllustration(c.state.sceneId,c.state.flags);if(art)await expect(page.getByTestId('scene-illustration').locator('img')).toHaveAttribute('src',art.src);expect(await saved(page)).toBe(before);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await cleanup(page);
  25 | });
  26 | for(const failure of['download','decode'])for(const c of cases)test(`scene performance ${c.delivery.id}: ${failure} falls back once at the measured source level`,async({page})=>{
  27 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);await page.route(path,r=>r.fulfill({status:failure==='download'?404:200,contentType:'audio/mpeg',body:'Unavailable'}));await open(page,c.state,{automatic:false});const before=await saved(page);await manual(page,c);await expect.poll(async()=>(await audio(page)).disposed,{timeout:20000}).toContain(c.delivery.id+'.mp3');expect(paths).toEqual([path,original]);expect((await audio(page)).voiceLevels.find(l=>l.file===c.delivery.id+'.mp3')!.gain).toBeCloseTo(c.delivery.fallbackGain,6);expect(await saved(page)).toBe(before);await cleanup(page);
  28 | });
  29 | for(const c of cases)test(`scene performance ${c.delivery.id}: both missing leave words and canonical exit`,async({page})=>{
  30 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);await page.route(path,r=>r.fulfill({status:404,body:'Missing'}));await page.route(original,r=>r.fulfill({status:404,body:'Missing'}));await open(page,c.state,{automatic:false});const before=await saved(page);const v=await manual(page,c);await expect(v).toHaveAttribute('data-playback','unavailable');expect(paths).toEqual([path,original]);await expect(page.getByTestId('scene-text')).toContainText(c.delivery.text);expect(await saved(page)).toBe(before);const ch=presentChoices(c.state,getScene(c.state.sceneId)).find(ch=>ch.enabled&&!ch.check)!;await page.getByTestId('choice-'+ch.id).click();await expect.poll(async()=>JSON.parse((await saved(page))!)).toEqual(commitChoice(c.state,ch).state);await cleanup(page);
  31 | });
  32 | for(const fallback of[false,true])for(const c of cases)test(`scene performance ${c.delivery.id}: Stop cancels late ${fallback?'original':'preferred'}`,async({page})=>{
  33 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);let release!:()=>void;const gate=new Promise<void>(r=>release=r);if(fallback)await page.route(path,r=>r.fulfill({status:404,body:'Missing'}));await page.route(fallback?original:path,async r=>{await gate;await r.continue();});try{await open(page,c.state,{automatic:false});const before=await saved(page);const v=await manual(page,c);await expect.poll(()=>paths).toContain(fallback?original:path);await v.getByRole('button',{name:'Stop line',exact:true}).click();release();await expect.poll(async()=>(await audio(page)).decoded).toContain(c.delivery.id+'.mp3');expect((await audio(page)).started.filter(n=>n===c.delivery.id+'.mp3')).toEqual([]);expect(await saved(page)).toBe(before);await cleanup(page);}finally{release();await page.unrouteAll({behavior:'ignoreErrors'});}
  34 | });
  35 | for(const c of cases)test(`scene performance ${c.delivery.id}: paragraph manual and text-only retain control`,async({page})=>{
  36 |  const art:string[]=[];page.on('request',r=>{if(new URL(r.url()).pathname.startsWith('/art/'))art.push(r.url());});const paths=requests(page);await open(page,c.state,{automatic:false,paragraph:true});const before=await saved(page);expect(paths).toEqual([]);const rest=page.getByTestId('show-rest');if(await rest.count())await rest.click();await expect(page.getByTestId('scene-text')).toContainText(c.delivery.text);const v=await manual(page,c);await expect(v).toHaveAttribute('data-playback','playing');await expect(page.getByTestId('spoken-quote')).toContainText(c.delivery.text);await v.getByRole('button',{name:'Stop line',exact:true}).click();expect(art).toEqual([]);expect(await saved(page)).toBe(before);await cleanup(page);
  37 | });
  38 | for(const fallback of[false,true])for(const c of cases)test(`scene performance ${c.delivery.id}: replay retains cached ${fallback?'original':'preferred'} level`,async({page})=>{
> 39 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);if(fallback)await page.route(path,r=>r.fulfill({status:404,body:'Missing'}));await open(page,c.state,{automatic:false});const before=await saved(page);const v=await manual(page,c);await expect.poll(async()=>(await audio(page)).disposed.filter(n=>n===c.delivery.id+'.mp3').length,{timeout:20000}).toBe(1);await v.getByRole('button',{name:'Listen to '+c.delivery.speaker,exact:true}).click();await expect.poll(async()=>(await audio(page)).disposed.filter(n=>n===c.delivery.id+'.mp3').length,{timeout:20000}).toBe(2);expect(paths).toEqual(fallback?[path,original]:[path]);expect((await audio(page)).voiceLevels.filter(l=>l.file===c.delivery.id+'.mp3').map(l=>l.gain)).toEqual([fallback?c.delivery.fallbackGain:1,fallback?c.delivery.fallbackGain:1]);expect(await saved(page)).toBe(before);await cleanup(page);
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              ^ Error: expect(received).toEqual(expected) // deep equality
  40 | });
  41 | for(const[sound,voices]of[[false,70],[true,0]]as const)for(const c of cases)test(`scene performance ${c.delivery.id}: sound${sound}/voices${voices} makes no voice request`,async({page})=>{
  42 |  const paths=requests(page);await open(page,c.state,{sound,voices});expect(paths).toEqual([]);expect((await audio(page)).started.filter(n=>n.startsWith('voice-'))).toEqual([]);await cleanup(page);
  43 | });
  44 | 
```