# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: scene-performance.spec.ts >> scene performance voice-campaign-mara-account-3aed03ac8227: replay retains cached original level
- Location: tests/scene-performance.spec.ts:38:60

# Error details

```
Error: expect(received).toEqual(expected) // deep equality

- Expected  - 0
+ Received  + 2

  Array [
    "/audio/connected-scenes-v2/voice-campaign-mara-account-3aed03ac8227.mp3",
    "/audio/voice-campaign-mara-account-3aed03ac8227.mp3",
+   "/audio/connected-scenes-v2/voice-campaign-mara-account-3aed03ac8227.mp3",
+   "/audio/voice-campaign-mara-account-3aed03ac8227.mp3",
  ]
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - link "Skip to choices" [ref=e4] [cursor=pointer]:
      - /url: "#choices"
    - banner [ref=e5]:
      - generic [ref=e12]:
        - text: Saint Shard
        - generic [ref=e13]: Kite City 3055
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Strain
          - meter "Strain 0 of 5" [ref=e19]
        - generic [ref=e25]: 390 cr
      - generic [ref=e28]:
        - button "Settings" [ref=e29] [cursor=pointer]
        - button "Saves" [ref=e30] [cursor=pointer]
        - button "Sheet" [ref=e31] [cursor=pointer]
        - button "Abandon" [ref=e32] [cursor=pointer]
    - main [ref=e34]:
      - article [ref=e35]:
        - generic [ref=e36]:
          - figure [ref=e37]:
            - generic "Mara · The patient" [ref=e38]:
              - generic [ref=e39]: Mara
              - generic [ref=e40]: The patient
          - generic [ref=e41]:
            - paragraph [ref=e42]:
              - text: Clinic side room, Ward Four
              - generic [ref=e46]: · The Week
            - heading "Clinic side room, Ward Four · The Week" [level=1] [ref=e47]
            - paragraph [ref=e48]: The week wants a buyer or a witness.
            - paragraph [ref=e49]: Clinic side room, Ward Four · The Week. The week wants a buyer or a witness.
        - status [ref=e50]: Loaded Autosave — The Week · Clinic side room, Ward Four
        - 'figure "Ward Four · a conversation with a past View artwork: Ward Four · a conversation with a past" [ref=e51]':
          - img "Mara listens beside a rainy clinic window, one hand resting on her knee and the other out of view; an untouched ceramic cup stands between her and an empty visitor chair." [ref=e54]
          - generic [ref=e55]:
            - generic [ref=e56]: Ward Four · a conversation with a past
            - 'button "View artwork: Ward Four · a conversation with a past" [ref=e57] [cursor=pointer]': View artwork
        - generic [ref=e58]:
          - paragraph [ref=e59]: Mara takes a breath before she answers. The rain has worked a bright line down the window frame.
          - paragraph [ref=e60]: "\"You stayed in that sentence. Thank you. It is harder to talk to someone who keeps disappearing behind the job.\""
          - paragraph [ref=e61]: She moves her cup off the unused chair's side of the table. If you return later, there may be something ordinary to ask her about.
        - complementary "Mara selected dialogue" [ref=e62]:
          - button "Listen to Mara" [active] [ref=e63] [cursor=pointer]
          - status [ref=e64]: Selected dialogue · Line 1 of 1 · synthetic voice
          - group [ref=e67]:
            - generic "Voice transcript" [ref=e68] [cursor=pointer]
            - list [ref=e69]:
              - listitem [ref=e70]:
                - strong [ref=e71]: "Mara:"
                - text: You stayed in that sentence. Thank you. It is harder to talk to someone who keeps disappearing behind the job.
        - region [ref=e72]:
          - generic [ref=e73]:
            - heading "Your next move" [level=2] [ref=e74]
            - link "Review your records" [ref=e75] [cursor=pointer]:
              - /url: "#decision-records"
            - paragraph [ref=e76]: Review costs before choosing.
          - button "Return to the letter’s terms." [ref=e77] [cursor=pointer]:
            - generic [ref=e78]: "1"
            - generic [ref=e84]:
              - generic [ref=e85]: Details
              - generic [ref=e86]: Dispatch and company keep their existing terms and costs.
        - region [ref=e87]:
          - heading "Commitments and history" [level=2] [ref=e88]
          - region "Current commitments" [ref=e90]:
            - group [ref=e91]:
              - generic "Campaign commitments · 0/1 complete · 1 open" [ref=e92] [cursor=pointer]
          - region "Choice reference" [ref=e93]:
            - heading "Choosing an action" [level=3] [ref=e94]
            - paragraph [ref=e95]: Selecting an option commits it. For a check, review the odds and costs first; Back leaves it unrolled.
          - link "Back to choices" [ref=e96] [cursor=pointer]:
            - /url: "#choices"
```

# Test source

```ts
  1  | import {test,expect,type Page}from '@playwright/test';
  2  | import {SCENE_PERFORMANCE_CHECKPOINTS}from '../qa/production/scene-performance-checkpoints';
  3  | import {getScene,sceneText,presentChoices,commitChoice}from '../lib/engine';
  4  | import {performanceVoicePath}from '../lib/performance-delivery';
  5  | import {voiceLevel}from '../lib/voice-level';
  6  | import {scenePerformanceLevel}from '../lib/scene-performance';
  7  | import {sceneIllustration}from '../lib/art';
  8  | import {installAudioReview,type AudioReview}from '../qa/production/audio-review';
  9  | import type{GameState}from '../lib/types';
  10 | const audio=(p:Page)=>p.evaluate(()=>(window as unknown as{audioReview:AudioReview}).audioReview);
  11 | const saved=(p:Page)=>p.evaluate(()=>localStorage.getItem('saint-shard-3055-v1'));
  12 | const cases=SCENE_PERFORMANCE_CHECKPOINTS;
  13 | const file=(id:string)=>id+(id.startsWith('voice-campaign-')?'.mp3':'.wav');
  14 | async function open(p:Page,state:GameState,{width=390,automatic=true,sound=true,voices=70,paragraph=false}={}){
  15 |  await p.setViewportSize({width,height:900});await p.addInitScript(installAudioReview,{});await p.addInitScript(({state,automatic,sound,voices,paragraph})=>{localStorage.setItem('saint-shard-3055-v1',JSON.stringify(state));localStorage.setItem('saint-shard-preferences',JSON.stringify({sound,voices,autoVoices:automatic,music:60,ambience:50,effects:0,reading:paragraph?'paragraph':'all',artwork:paragraph?'none':'full',textStep:2,motion:'reduce'}));},{state,automatic,sound,voices,paragraph});await p.goto('/');await p.getByTestId('continue-run').click();await expect(p.getByTestId('goal')).toBeVisible();
  16 | }
  17 | function requests(p:Page){const paths:string[]=[];p.on('request',r=>{const path=new URL(r.url()).pathname;if(path.includes('/voice-'))paths.push(path);});return paths;}
  18 | async function manual(p:Page,c:typeof cases[number]){const v=p.getByTestId('voice-line');await v.locator('summary').click();if(c.lines.length>1)await v.getByLabel('Dialogue line',{exact:true}).selectOption(c.lines.find(l=>l.id===c.delivery.id)!.key);await v.getByRole('button',{name:'Listen to '+c.delivery.speaker,exact:true}).click();return v;}
  19 | async function cleanup(p:Page){await p.evaluate(()=>window.dispatchEvent(new PageTransitionEvent('pagehide',{persisted:true})));await expect.poll(async()=>(await audio(p)).liveSources).toBe(0);const a=await audio(p);expect(a.sourcesCreated).toBe(a.sourcesDisposed);expect(a.sourcesCreated).toBe(a.buffersCleared);}
  20 | for(const width of[390,1440])for(const c of cases)test(`scene performance ${c.delivery.id}: complete words, actor, art and natural queue at${width}`,async({page})=>{
  21 |  const paths=requests(page);await open(page,c.state,{width});const before=await saved(page);await expect(page.getByTestId('scene-text')).toHaveText(sceneText(getScene(c.state.sceneId),c.state).split(/\n\n+/).filter(Boolean).join(''));
  22 |  for(const l of c.lines){await expect(page.getByTestId('spoken-quote')).toContainText(l.text);await expect(page.getByTestId('spoken-quote')).toHaveAttribute('data-speaker',l.speaker);await expect.poll(async()=>(await audio(page)).disposed,{timeout:20000}).toContain(file(l.id));}
  23 |  const a=await audio(page);expect(a.started.filter(f=>f.startsWith('voice-'))).toEqual(c.lines.map(l=>file(l.id)));expect(paths).toEqual(c.lines.map(l=>performanceVoicePath(l.id)??'/audio/'+file(l.id)));for(const l of c.lines){const path=performanceVoicePath(l.id)??'/audio/'+file(l.id);expect(a.voiceLevels.find(r=>r.file===file(l.id))!.gain).toBeCloseTo(scenePerformanceLevel(l.id,path)??voiceLevel(l.id),6);}
  24 |  const art=sceneIllustration(c.state.sceneId,c.state.flags);if(art)await expect(page.getByTestId('scene-illustration').locator('img')).toHaveAttribute('src',art.src);expect(await saved(page)).toBe(before);expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);await cleanup(page);
  25 | });
  26 | for(const failure of['download','decode'])for(const c of cases)test(`scene performance ${c.delivery.id}: ${failure} falls back once at the measured source level`,async({page})=>{
  27 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);await page.route(path,r=>r.fulfill({status:failure==='download'?404:200,contentType:'audio/mpeg',body:'Unavailable'}));await open(page,c.state,{automatic:false});const before=await saved(page);await manual(page,c);await expect.poll(async()=>(await audio(page)).disposed,{timeout:20000}).toContain(c.delivery.id+'.mp3');expect(paths).toEqual([path,original]);expect((await audio(page)).voiceLevels.find(l=>l.file===c.delivery.id+'.mp3')!.gain).toBeCloseTo(c.delivery.fallbackGain,6);expect(await saved(page)).toBe(before);await cleanup(page);
  28 | });
  29 | for(const c of cases)test(`scene performance ${c.delivery.id}: both missing leave words and canonical exit`,async({page})=>{
  30 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);await page.route(path,r=>r.fulfill({status:404,body:'Missing'}));await page.route(original,r=>r.fulfill({status:404,body:'Missing'}));await open(page,c.state,{automatic:false});const before=await saved(page);const v=await manual(page,c);await expect(v).toHaveAttribute('data-playback','unavailable');expect(paths).toEqual([path,original]);await expect(page.getByTestId('scene-text')).toContainText(c.delivery.text);expect(await saved(page)).toBe(before);const ch=presentChoices(c.state,getScene(c.state.sceneId)).find(ch=>ch.enabled&&!ch.check)!;await page.getByTestId('choice-'+ch.id).click();await expect.poll(async()=>JSON.parse((await saved(page))!)).toEqual(commitChoice(c.state,ch).state);await cleanup(page);
  31 | });
  32 | for(const fallback of[false,true])for(const c of cases)test(`scene performance ${c.delivery.id}: Stop cancels late ${fallback?'original':'preferred'}`,async({page})=>{
  33 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);let release!:()=>void;const gate=new Promise<void>(r=>release=r);if(fallback)await page.route(path,r=>r.fulfill({status:404,body:'Missing'}));await page.route(fallback?original:path,async r=>{await gate;await r.continue();});try{await open(page,c.state,{automatic:false});const before=await saved(page);const v=await manual(page,c);await expect.poll(()=>paths).toContain(fallback?original:path);await v.getByRole('button',{name:'Stop line',exact:true}).click();release();await expect.poll(async()=>(await audio(page)).decoded).toContain(c.delivery.id+'.mp3');expect((await audio(page)).started.filter(n=>n===c.delivery.id+'.mp3')).toEqual([]);expect(await saved(page)).toBe(before);await cleanup(page);}finally{release();await page.unrouteAll({behavior:'ignoreErrors'});}
  34 | });
  35 | for(const c of cases)test(`scene performance ${c.delivery.id}: paragraph manual and text-only retain control`,async({page})=>{
  36 |  const art:string[]=[];page.on('request',r=>{if(new URL(r.url()).pathname.startsWith('/art/'))art.push(r.url());});const paths=requests(page);await open(page,c.state,{automatic:false,paragraph:true});const before=await saved(page);expect(paths).toEqual([]);const rest=page.getByTestId('show-rest');if(await rest.count())await rest.click();await expect(page.getByTestId('scene-text')).toContainText(c.delivery.text);const v=await manual(page,c);await expect(v).toHaveAttribute('data-playback','playing');await expect(page.getByTestId('spoken-quote')).toContainText(c.delivery.text);await v.getByRole('button',{name:'Stop line',exact:true}).click();expect(art).toEqual([]);expect(await saved(page)).toBe(before);await cleanup(page);
  37 | });
  38 | for(const fallback of[false,true])for(const c of cases)test(`scene performance ${c.delivery.id}: replay retains cached ${fallback?'original':'preferred'} level`,async({page})=>{
> 39 |  const path=performanceVoicePath(c.delivery.id)!,original='/'+c.delivery.fallbackPath.slice(7),paths=requests(page);if(fallback)await page.route(path,r=>r.fulfill({status:404,body:'Missing'}));await open(page,c.state,{automatic:false});const before=await saved(page);const v=await manual(page,c);await expect.poll(async()=>(await audio(page)).disposed.filter(n=>n===c.delivery.id+'.mp3').length,{timeout:20000}).toBe(1);await v.getByRole('button',{name:'Listen to '+c.delivery.speaker,exact:true}).click();await expect.poll(async()=>(await audio(page)).disposed.filter(n=>n===c.delivery.id+'.mp3').length,{timeout:20000}).toBe(2);expect(paths).toEqual(fallback?[path,original]:[path]);const levels=(await audio(page)).voiceLevels.filter(l=>l.file===c.delivery.id+'.mp3').map(l=>l.gain);const expected=Math.fround(fallback?c.delivery.fallbackGain:1);expect(levels).toEqual([expected,expected]);expect(await saved(page)).toBe(before);await cleanup(page);
     |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     ^ Error: expect(received).toEqual(expected) // deep equality
  40 | });
  41 | for(const[sound,voices]of[[false,70],[true,0]]as const)for(const c of cases)test(`scene performance ${c.delivery.id}: sound${sound}/voices${voices} makes no voice request`,async({page})=>{
  42 |  const paths=requests(page);await open(page,c.state,{sound,voices});expect(paths).toEqual([]);expect((await audio(page)).started.filter(n=>n.startsWith('voice-'))).toEqual([]);await cleanup(page);
  43 | });
  44 | 
```