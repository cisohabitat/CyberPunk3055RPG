# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation-release.spec.ts >> workshop comparison keeps complete terms with less real travel: 1440/0
- Location: tests/navigation-release.spec.ts:9:38

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 2058.054375
Received:    2061.390625
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - link "Skip to choices" [ref=e4] [cursor=pointer]:
      - /url: "#choices"
    - banner [ref=e5]:
      - generic [ref=e12]:
        - text: Saint Shard
        - generic [ref=e13]: Kite City 3055
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Strain
          - meter "Strain 1 of 5" [ref=e19]
        - generic [ref=e25]: 0 cr
      - generic [ref=e28]:
        - button "Settings" [ref=e29] [cursor=pointer]
        - button "Saves" [ref=e30] [cursor=pointer]
        - button "Abandon" [ref=e31] [cursor=pointer]
    - generic [ref=e32]:
      - main [ref=e33]:
        - article [active] [ref=e34]:
          - generic [ref=e35]:
            - figure [ref=e36]:
              - generic "Quill · The broker" [ref=e38]:
                - generic [ref=e39]: Quill
                - generic [ref=e40]: The broker
            - generic [ref=e41]:
              - paragraph [ref=e42]:
                - text: District repair bench
                - generic [ref=e46]: · The Week
              - heading "District repair bench · The Week" [level=1] [ref=e47]
              - paragraph [ref=e48]: The week wants a buyer or a witness.
              - paragraph [ref=e49]: District repair bench · The Week. The week wants a buyer or a witness.
          - status [ref=e50]: Loaded Autosave — The Week · District repair bench
          - generic [ref=e51]:
            - paragraph [ref=e52]: Quill has laid four cases on the repair bench. None is an all-purpose answer. A probe belongs at a reader, a harness under a chair, a desk guide beside a form, and a shroud on a service route.
            - paragraph [ref=e53]: "'One case in this shipment for you,' he says. 'Keep enough for the person on the other end of the job.'"
            - paragraph [ref=e54]: An unregistered clinic room for Nia costs ninety creds. Staffed recovery for you costs forty-five. Tools can improve a route; they reserve no room and buy no person's consent. You can leave the cases and come back before the week closes.
          - complementary "Quill selected dialogue" [ref=e55]:
            - button "Listen to Quill" [disabled] [ref=e56] [cursor=pointer]
            - button "Play all dialogue" [disabled] [ref=e57] [cursor=pointer]
            - status [ref=e58]: Enable Sound and voice volume in Settings to listen.
            - group [ref=e62]:
              - generic "Voice transcript" [ref=e63] [cursor=pointer]
              - option "1. Quill · One case in this shipment for you,"
              - option "2. Quill · Keep enough for the person on the other end of the job." [selected]
          - region [ref=e64]:
            - generic [ref=e65]:
              - heading "Your next move" [level=2] [ref=e66]
              - paragraph [ref=e67]: Selecting an option commits it.
            - complementary "Compare field equipment" [ref=e68]:
              - heading "Compare field equipment" [level=2] [ref=e69]
              - paragraph [ref=e70]:
                - text: One field kit this week ·
                - strong [ref=e71]: 0 creds available
                - text: . Private witness care costs 90; staffed recovery costs 45.
              - paragraph [ref=e72]: "Only the listed checks receive the bonus. Equipment supplies no evidence, safe room, or consent. Cash benchmarks: room 90 + staffed rest 45 = 135; adding private courier dispatch 15 brings the combined cost to 150. These comparisons reserve nothing; earned rooms and other legal methods remain available."
              - link "Review leaving without buying" [ref=e73] [cursor=pointer]:
                - /url: "#campaign-choice-leave-workshop"
              - generic [ref=e74]:
                - generic [ref=e75]:
                  - term [ref=e76]: Archive Probe · 140 creds
                  - definition [ref=e77]:
                    - text: +2 to scanner inspection, archive index preparation, receipt authentication, and the depot sensor ramp. Works without training this skill.
                    - group [ref=e78]:
                      - generic "Compare current check odds" [ref=e79] [cursor=pointer]
                    - paragraph [ref=e80]: Need 140 more creds to buy this kit.
                    - generic [ref=e81]:
                      - button "Review Archive Probe purchase" [disabled] [ref=e82] [cursor=pointer]
                      - paragraph [ref=e83]: Need 140 creds
                    - button "Buy the Archive Probe." [disabled] [ref=e85]:
                      - generic [ref=e86]: "1"
                      - generic [ref=e91]: Need 140 creds
                - generic [ref=e93]:
                  - term [ref=e94]: Chair Harness · 120 creds
                  - definition [ref=e95]:
                    - text: +2 to chair preparation, physical witness transfer, archive hatch preparation, physical ledger inspection, carrying sealed clinic cards, the shelter valve, and carrying Kerr’s case. A braced chair permits a no-roll transfer; Steady hands avoids its added strain. Your practiced skill has its own methods.
                    - group [ref=e96]:
                      - generic "How the Chair Harness fits your training" [ref=e97] [cursor=pointer]
                    - group [ref=e98]:
                      - generic "Compare current check odds" [ref=e99] [cursor=pointer]
                    - paragraph [ref=e100]: Need 120 more creds to buy this kit.
                    - generic [ref=e101]:
                      - button "Review Chair Harness purchase" [disabled] [ref=e102] [cursor=pointer]
                      - paragraph [ref=e103]: Need 120 creds
                    - button "Buy the Chair Harness." [disabled] [ref=e105]:
                      - generic [ref=e106]: "2"
                      - generic [ref=e111]: Need 120 creds
                - generic [ref=e113]:
                  - term [ref=e114]: Clinic Desk Guide · 100 creds
                  - definition [ref=e115]:
                    - text: +2 to arranging a volunteer escort, negotiating a checkpoint transfer, private clinic dispatch, and the depot counter. It supplies procedure, not a forged signature. Works without training this skill.
                    - group [ref=e116]:
                      - generic "Compare current check odds" [ref=e117] [cursor=pointer]
                    - paragraph [ref=e118]: Need 100 more creds to buy this kit.
                    - generic [ref=e119]:
                      - button "Review Clinic Desk Guide purchase" [disabled] [ref=e120] [cursor=pointer]
                      - paragraph [ref=e121]: Need 100 creds
                    - button "Buy the Clinic Desk Guide." [disabled] [ref=e123]:
                      - generic [ref=e124]: "3"
                      - generic [ref=e129]: Need 100 creds
                - generic [ref=e131]:
                  - term [ref=e132]: Route Shroud · 140 creds
                  - definition [ref=e133]:
                    - text: +2 to patrol scouting, service-hatch witness transfer, archive interval preparation, carbon retrieval, and the depot patrol gap. Works without training this skill.
                    - group [ref=e134]:
                      - generic "Compare current check odds" [ref=e135] [cursor=pointer]
                    - paragraph [ref=e136]: Need 140 more creds to buy this kit.
                    - generic [ref=e137]:
                      - button "Review Route Shroud purchase" [disabled] [ref=e138] [cursor=pointer]
                      - paragraph [ref=e139]: Need 140 creds
                    - button "Buy the Route Shroud." [disabled] [ref=e141]:
                      - generic [ref=e142]: "4"
                      - generic [ref=e147]: Need 140 creds
            - button "Keep the care budget. Return to the district board." [ref=e149] [cursor=pointer]:
              - generic [ref=e150]: "5"
          - region "Commitments and history" [ref=e155]:
            - region "Current commitments" [ref=e157]:
              - paragraph [ref=e158]:
                - strong [ref=e159]: Next step
                - text: Compare one kit against the money needed for care. Tools improve specific checks, not base stats.
              - group [ref=e162]:
                - generic "Memory commitments · 0/1 complete · 1 open" [ref=e163] [cursor=pointer]
            - region "Choice reference" [ref=e164]:
              - paragraph [ref=e165]: Selecting an option commits it. For a check, review the odds and costs first; Back leaves it unrolled.
              - group [ref=e166]:
                - generic "Review unavailable approaches (4)" [ref=e167]
      - complementary "Character sheet" [ref=e168]:
        - generic [ref=e175]:
          - heading "Replay" [level=2] [ref=e176]
          - paragraph [ref=e177]: Dustline · Ada
        - button "City map" [ref=e178] [cursor=pointer]
        - group [ref=e181]:
          - generic "Origin & complication" [ref=e182] [cursor=pointer]
        - group [ref=e183]:
          - generic "People · 5 met" [ref=e184] [cursor=pointer]
        - tablist "Character details" [ref=e185]:
          - tab "stats" [selected] [ref=e186] [cursor=pointer]
          - tab "gear" [ref=e187] [cursor=pointer]
          - tab "journal" [ref=e188] [cursor=pointer]
        - tabpanel "stats" [ref=e189]:
          - paragraph [ref=e190]:
            - strong [ref=e191]: Steady hands
            - text: · Nerve checks +1. Hold an archive hatch for Edda; chair preparation unlocks a physical transfer route.
          - generic [ref=e192]:
            - generic [ref=e193]: Chrome
            - generic [ref=e196]: "2"
          - generic [ref=e199]:
            - generic [ref=e200]: Nerve
            - generic [ref=e203]: "2"
          - generic [ref=e206]:
            - generic [ref=e207]: Face
            - generic [ref=e210]: "1"
          - generic [ref=e213]:
            - generic [ref=e214]: Ghost
            - generic [ref=e217]: "5"
          - group [ref=e220]:
            - generic "How stats work" [ref=e221] [cursor=pointer]
          - heading "Factions" [level=3] [ref=e222]
          - generic [ref=e223]:
            - generic [ref=e224]: Quill
            - generic [ref=e227]: "3"
          - generic [ref=e230]:
            - generic [ref=e231]: Lumen
            - generic [ref=e234]: "2"
          - generic [ref=e237]:
            - generic [ref=e238]: Helion
            - generic [ref=e241]: "4"
          - generic [ref=e244]:
            - generic [ref=e245]: The wards
            - generic [ref=e248]: "1"
          - group [ref=e251]:
            - generic "How factions affect checks" [ref=e252] [cursor=pointer]
          - group [ref=e253]:
            - generic "What you did · 6 recent" [ref=e254] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import AxeBuilder from '@axe-core/playwright';
  3  | import baseline from '../qa/editorial/navigation-release-layout-baseline.json';
  4  | import { keyboardActivate } from '../qa/production/keyboard';
  5  | import type { GameState } from '../lib/types';
  6  | import { FIELD_KITS } from '../lib/loadout';
  7  | import { commitChoice, getScene, presentChoices } from '../lib/engine';
  8  | 
  9  | for (const row of baseline.rows) test(`workshop comparison keeps complete terms with less real travel: ${row.width}/${row.creds}`, async ({ page }, info) => {
  10 |   await page.setViewportSize({ width: row.width, height: 900 });
  11 |   await page.addInitScript(state => {
  12 |     if (!localStorage.getItem('saint-shard-3055-v1')) localStorage.setItem('saint-shard-3055-v1', JSON.stringify(state));
  13 |     localStorage.setItem('saint-shard-preferences', JSON.stringify({ sound: false, reading: 'all', artwork: 'none', textStep: 2, contrast: 'high', motion: 'reduce' }));
  14 |   }, row.state);
  15 |   await page.goto('/'); await page.getByTestId('continue-run').click(); await page.evaluate(() => document.fonts.ready);
  16 |   const saved = () => page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'));
  17 |   const before = await saved();
  18 |   const metrics = await page.getByTestId('scene').evaluate(root => {
  19 |     const bottom = root.querySelector('[data-testid="scene-text"]')!.getBoundingClientRect().bottom;
  20 |     const controls = [...root.querySelectorAll<HTMLElement>('button,a,summary,input,select')].filter(n => n.getBoundingClientRect().height > 0);
  21 |     return {
  22 |       text: (root as HTMLElement).innerText,
  23 |       controls: controls.map(n => ({ tag: n.tagName, id: n.dataset.testid || n.id, text: n.innerText, disabled: n.hasAttribute('disabled') })),
  24 |       actions: controls.filter(n => n.dataset.testid?.startsWith('choice-')).map(n => ({ id: n.dataset.testid, gap: n.getBoundingClientRect().top - bottom, height: n.getBoundingClientRect().height, disabled: n.hasAttribute('disabled') })),
  25 |       typography: [...root.querySelectorAll<HTMLElement>('p,dt,h2,h3,button,summary')].filter(n => n.getBoundingClientRect().height > 0).map(n => ({ text: n.innerText, tag: n.tagName, font: getComputedStyle(n).fontSize, line: getComputedStyle(n).lineHeight })),
  26 |       reviewExitPx: root.querySelector('[data-testid="review-workshop-exit"]')!.getBoundingClientRect().top - bottom,
  27 |       overflow: document.documentElement.scrollWidth > innerWidth,
  28 |     };
  29 |   });
  30 |   expect(metrics.text).toBe(row.metrics.text);
  31 |   expect(metrics.controls).toEqual(row.metrics.controls);
  32 |   // Baseline was captured in Chromium; native font serialization is checked in
  33 |   // that engine. Every engine retains the exact same DOM/style font rules.
  34 |   if (info.project.name === 'chromium') expect(metrics.typography).toEqual(row.metrics.typography);
  35 |   expect(metrics.overflow).toBe(false);
  36 |   const exit = metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  37 |   const oldExit = row.metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  38 |   // Independent source-bound baseline; never move a marker to satisfy travel.
  39 |   if (info.project.name === 'chromium') {
> 40 |     expect(exit.gap).toBeLessThanOrEqual(oldExit.gap * .92);
     |                      ^ Error: expect(received).toBeLessThanOrEqual(expected)
  41 |     expect(metrics.reviewExitPx).toBeLessThanOrEqual(row.metrics.reviewExitPx);
  42 |     for (const action of metrics.actions) expect(action.gap).toBeLessThanOrEqual(row.metrics.actions.find(a => a.id === action.id)!.gap);
  43 |   }
  44 |   for (const action of metrics.actions) if (!action.disabled) expect(action.height).toBeGreaterThanOrEqual(44);
  45 |   await expect(page.getByTestId('goal')).toBeInViewport();
  46 |   // Original controls, native tab order and actual same keyboard helper:
  47 |   // no new Tab stops, duplicated commits, hidden terms or gesture interceptor.
  48 |   for (const kit of FIELD_KITS) {
  49 |     const review = page.getByTestId(`review-purchase-${kit.id}`), purchase = page.getByTestId(`choice-buy-${kit.id}`);
  50 |     if (await review.isEnabled()) {
  51 |       await keyboardActivate(page, review); await expect(purchase).toBeFocused(); await expect(purchase.locator('.label')).toBeInViewport();
  52 |       expect(await saved()).toBe(before);
  53 |     } else await expect(purchase).toBeDisabled();
  54 |   }
  55 |   await keyboardActivate(page, page.getByTestId('review-workshop-exit'));
  56 |   await expect(page.getByTestId('choice-leave-workshop')).toBeFocused();
  57 |   expect(await saved()).toBe(before);
  58 |   expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
  59 |   const choice = presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.enabled && c.id.startsWith('buy-')) ?? presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.id === 'leave-workshop')!;
  60 |   await keyboardActivate(page, page.getByTestId(`choice-${choice.id}`));
  61 |   const expected = commitChoice(row.state as GameState, choice).state;
  62 |   await expect.poll(async () => JSON.parse((await saved())!)).toEqual(expected);
  63 |   await page.reload(); await page.getByTestId('continue-run').click(); expect(JSON.parse((await saved())!)).toEqual(expected);
  64 |   await info.attach('workshop-task', { body: JSON.stringify({ baseline: row.metrics, current: metrics }), contentType: 'application/json' });
  65 | });
  66 | 
  67 | for (const row of baseline.rows.filter(r => r.creds === 275)) test(`workshop native odds inspections preserve save and normal scroll at${row.width}px`, async ({ page }) => {
  68 |   await page.setViewportSize({ width: row.width, height: 900 });
  69 |   await page.addInitScript(state => {
  70 |     localStorage.setItem('saint-shard-3055-v1', JSON.stringify(state));
  71 |     localStorage.setItem('saint-shard-preferences', JSON.stringify({ sound: false, reading: 'all', artwork: 'none', textStep: 2, contrast: 'high', motion: 'reduce' }));
  72 |   }, row.state);
  73 |   await page.goto('/'); await page.getByTestId('continue-run').click();
  74 |   const before = await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'));
  75 |   for (const kit of FIELD_KITS) {
  76 |     const panel = page.getByTestId(`kit-odds-${kit.id}`);
  77 |     await keyboardActivate(page, panel.locator('summary')); await expect(panel).toHaveAttribute('open', '');
  78 |     await expect(panel.locator('ul')).toBeVisible();
  79 |     expect(await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'))).toBe(before);
  80 |     await keyboardActivate(page, panel.locator('summary'));
  81 |   }
  82 |   const end = await page.evaluate(() => { scrollTo(0, document.documentElement.scrollHeight); return scrollY; });
  83 |   expect(end).toBeGreaterThan(900);
  84 |   await page.evaluate(() => scrollTo(0, 0)); expect(await page.evaluate(() => scrollY)).toBe(0);
  85 |   expect(await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'))).toBe(before);
  86 | });
  87 | 
```