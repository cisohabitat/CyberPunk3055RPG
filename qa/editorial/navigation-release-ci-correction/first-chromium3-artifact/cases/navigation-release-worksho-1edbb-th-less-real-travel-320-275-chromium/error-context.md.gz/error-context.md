# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation-release.spec.ts >> workshop comparison keeps complete terms with less real travel: 320/275
- Location: tests/navigation-release.spec.ts:9:38

# Error details

```
Error: expect(received).toBeLessThanOrEqual(expected)

Expected: <= 1112.96875
Received:    1146.5625
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - link "Skip to choices" [ref=e4] [cursor=pointer]:
      - /url: "#choices"
    - banner [ref=e5]:
      - generic [ref=e12]:
        - text: Saint Shard
        - generic [ref=e13]: Kite City 3055
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Strain
          - meter "Strain 1 of 5" [ref=e19]
        - generic [ref=e25]: 275 cr
      - generic [ref=e28]:
        - button "Settings" [ref=e29] [cursor=pointer]
        - button "Saves" [ref=e30] [cursor=pointer]
        - button "Sheet" [ref=e31] [cursor=pointer]
        - button "Abandon" [ref=e32] [cursor=pointer]
    - main [ref=e34]:
      - article [active] [ref=e35]:
        - generic [ref=e36]:
          - figure [ref=e37]:
            - generic "Quill · The broker" [ref=e39]:
              - generic [ref=e40]: Quill
              - generic [ref=e41]: The broker
          - generic [ref=e42]:
            - paragraph [ref=e43]:
              - text: District repair bench
              - generic [ref=e47]: · The Week
            - heading "District repair bench · The Week" [level=1] [ref=e48]
            - paragraph [ref=e49]: The week wants a buyer or a witness.
            - paragraph [ref=e50]: District repair bench · The Week. The week wants a buyer or a witness.
        - status [ref=e51]: Loaded Autosave — The Week · District repair bench
        - generic [ref=e52]:
          - paragraph [ref=e53]: Quill has laid four cases on the repair bench. None is an all-purpose answer. A probe belongs at a reader, a harness under a chair, a desk guide beside a form, and a shroud on a service route.
          - paragraph [ref=e54]: "'One case in this shipment for you,' he says. 'Keep enough for the person on the other end of the job.'"
          - paragraph [ref=e55]: An unregistered clinic room for Nia costs ninety creds. Staffed recovery for you costs forty-five. Tools can improve a route; they reserve no room and buy no person's consent. You can leave the cases and come back before the week closes.
        - complementary "Quill selected dialogue" [ref=e56]:
          - button "Listen to Quill" [disabled] [ref=e57] [cursor=pointer]
          - button "Play all dialogue" [disabled] [ref=e58] [cursor=pointer]
          - status [ref=e59]: Enable Sound and voice volume in Settings to listen.
          - group [ref=e63]:
            - generic "Voice transcript" [ref=e64] [cursor=pointer]
            - option "1. Quill · One case in this shipment for you,"
            - option "2. Quill · Keep enough for the person on the other end of the job." [selected]
        - region [ref=e65]:
          - generic [ref=e66]:
            - heading "Your next move" [level=2] [ref=e67]
            - paragraph [ref=e68]: Selecting an option commits it.
          - complementary "Compare field equipment" [ref=e69]:
            - heading "Compare field equipment" [level=2] [ref=e70]
            - paragraph [ref=e71]:
              - text: One field kit this week ·
              - strong [ref=e72]: 275 creds available
              - text: . Private witness care costs 90; staffed recovery costs 45.
            - paragraph [ref=e73]: "Only the listed checks receive the bonus. Equipment supplies no evidence, safe room, or consent. Cash benchmarks: room 90 + staffed rest 45 = 135; adding private courier dispatch 15 brings the combined cost to 150. These comparisons reserve nothing; earned rooms and other legal methods remain available."
            - paragraph [ref=e74]: Find the purchase choice and review it. No money is spent until you select that choice.
            - link "Review leaving without buying" [ref=e75] [cursor=pointer]:
              - /url: "#campaign-choice-leave-workshop"
            - generic [ref=e76]:
              - generic [ref=e77]:
                - term [ref=e78]: Archive Probe · 140 creds
                - definition [ref=e79]:
                  - text: Works without training this skill.
                  - group [ref=e80]:
                    - generic "Compare current check odds" [ref=e81] [cursor=pointer]
                  - paragraph [ref=e82]:
                    - strong [ref=e83]: "After purchase: 135 creds."
                    - text: Enough cash remains for a room and staffed rest. Adding a private courier would need 15 more.
                  - button "Review Archive Probe purchase" [ref=e85] [cursor=pointer]
                  - button "Buy the Archive Probe." [ref=e87] [cursor=pointer]:
                    - generic [ref=e88]: "1"
                    - generic [ref=e93]:
                      - generic [ref=e94]:
                        - generic [ref=e95]: Details
                        - generic [ref=e96]: 140 creds. +2 to scanner inspection, archive index preparation, receipt authentication, and the depot sensor ramp. One field kit this week; it stays in your inventory.
                      - generic [ref=e97]:
                        - generic [ref=e98]: Changes
                        - generic [ref=e99]: "-140 cr · Gain Archive Probe"
              - generic [ref=e100]:
                - term [ref=e101]: Chair Harness · 120 creds
                - definition [ref=e102]:
                  - text: Your practiced skill has its own methods.
                  - group [ref=e103]:
                    - generic "How the Chair Harness fits your training" [ref=e104] [cursor=pointer]
                  - group [ref=e105]:
                    - generic "Compare current check odds" [ref=e106] [cursor=pointer]
                  - paragraph [ref=e107]:
                    - strong [ref=e108]: "After purchase: 155 creds."
                    - text: Enough cash remains for a room and staffed rest. A private courier also fits that combined budget.
                  - button "Review Chair Harness purchase" [ref=e110] [cursor=pointer]
                  - button "Buy the Chair Harness." [ref=e112] [cursor=pointer]:
                    - generic [ref=e113]: "2"
                    - generic [ref=e118]:
                      - generic [ref=e119]:
                        - generic [ref=e120]: Details
                        - generic [ref=e121]: 120 creds. +2 to chair preparation, physical witness transfer, archive hatch preparation, physical ledger inspection, carrying sealed clinic cards, the shelter valve, and carrying Kerr’s case. A braced chair permits a no-roll transfer; Steady hands avoids its added strain. One field kit this week; it stays in your inventory.
                      - generic [ref=e122]:
                        - generic [ref=e123]: Changes
                        - generic [ref=e124]: "-120 cr · Gain Chair Harness"
              - generic [ref=e125]:
                - term [ref=e126]: Clinic Desk Guide · 100 creds
                - definition [ref=e127]:
                  - text: Works without training this skill.
                  - group [ref=e128]:
                    - generic "Compare current check odds" [ref=e129] [cursor=pointer]
                  - paragraph [ref=e130]:
                    - strong [ref=e131]: "After purchase: 175 creds."
                    - text: Enough cash remains for a room and staffed rest. A private courier also fits that combined budget.
                  - button "Review Clinic Desk Guide purchase" [ref=e133] [cursor=pointer]
                  - button "Buy the Clinic Desk Guide." [ref=e135] [cursor=pointer]:
                    - generic [ref=e136]: "3"
                    - generic [ref=e141]:
                      - generic [ref=e142]:
                        - generic [ref=e143]: Details
                        - generic [ref=e144]: 100 creds. +2 to arranging a volunteer escort, negotiating a checkpoint transfer, private clinic dispatch, and the depot counter. It supplies procedure, not a forged signature. One field kit this week; it stays in your inventory.
                      - generic [ref=e145]:
                        - generic [ref=e146]: Changes
                        - generic [ref=e147]: "-100 cr · Gain Clinic Desk Guide"
              - generic [ref=e148]:
                - term [ref=e149]: Route Shroud · 140 creds
                - definition [ref=e150]:
                  - text: Works without training this skill.
                  - group [ref=e151]:
                    - generic "Compare current check odds" [ref=e152] [cursor=pointer]
                  - paragraph [ref=e153]:
                    - strong [ref=e154]: "After purchase: 135 creds."
                    - text: Enough cash remains for a room and staffed rest. Adding a private courier would need 15 more.
                  - button "Review Route Shroud purchase" [ref=e156] [cursor=pointer]
                  - button "Buy the Route Shroud." [ref=e158] [cursor=pointer]:
                    - generic [ref=e159]: "4"
                    - generic [ref=e164]:
                      - generic [ref=e165]:
                        - generic [ref=e166]: Details
                        - generic [ref=e167]: 140 creds. +2 to patrol scouting, service-hatch witness transfer, archive interval preparation, carbon retrieval, and the depot patrol gap. One field kit this week; it stays in your inventory.
                      - generic [ref=e168]:
                        - generic [ref=e169]: Changes
                        - generic [ref=e170]: "-140 cr · Gain Route Shroud"
          - button "Keep the care budget. Return to the district board." [ref=e171] [cursor=pointer]:
            - generic [ref=e172]: "5"
        - region "Commitments and history" [ref=e177]:
          - region "Current commitments" [ref=e179]:
            - paragraph [ref=e180]:
              - strong [ref=e181]: Next step
              - text: Compare one kit against the money needed for care. Tools improve specific checks, not base stats.
            - group [ref=e184]:
              - generic "Memory commitments · 0/1 complete · 1 open" [ref=e185] [cursor=pointer]
          - region "Choice reference" [ref=e186]:
            - paragraph [ref=e187]: Selecting an option commits it. For a check, review the odds and costs first; Back leaves it unrolled.
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import AxeBuilder from '@axe-core/playwright';
  3  | import baseline from '../qa/editorial/navigation-release-layout-baseline.json';
  4  | import { keyboardActivate } from '../qa/production/keyboard';
  5  | import type { GameState } from '../lib/types';
  6  | import { FIELD_KITS } from '../lib/loadout';
  7  | import { commitChoice, getScene, presentChoices } from '../lib/engine';
  8  | 
  9  | for (const row of baseline.rows) test(`workshop comparison keeps complete terms with less real travel: ${row.width}/${row.creds}`, async ({ page }, info) => {
  10 |   await page.setViewportSize({ width: row.width, height: 900 });
  11 |   await page.addInitScript(state => {
  12 |     if (!localStorage.getItem('saint-shard-3055-v1')) localStorage.setItem('saint-shard-3055-v1', JSON.stringify(state));
  13 |     localStorage.setItem('saint-shard-preferences', JSON.stringify({ sound: false, reading: 'all', artwork: 'none', textStep: 2, contrast: 'high', motion: 'reduce' }));
  14 |   }, row.state);
  15 |   await page.goto('/'); await page.getByTestId('continue-run').click(); await page.evaluate(() => document.fonts.ready);
  16 |   const saved = () => page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'));
  17 |   const before = await saved();
  18 |   const metrics = await page.getByTestId('scene').evaluate(root => {
  19 |     const bottom = root.querySelector('[data-testid="scene-text"]')!.getBoundingClientRect().bottom;
  20 |     const controls = [...root.querySelectorAll<HTMLElement>('button,a,summary,input,select')].filter(n => n.getBoundingClientRect().height > 0);
  21 |     return {
  22 |       text: (root as HTMLElement).innerText,
  23 |       controls: controls.map(n => ({ tag: n.tagName, id: n.dataset.testid || n.id, text: n.innerText, disabled: n.hasAttribute('disabled') })),
  24 |       actions: controls.filter(n => n.dataset.testid?.startsWith('choice-')).map(n => ({ id: n.dataset.testid, gap: n.getBoundingClientRect().top - bottom, height: n.getBoundingClientRect().height, disabled: n.hasAttribute('disabled') })),
  25 |       typography: [...root.querySelectorAll<HTMLElement>('p,dt,h2,h3,button,summary')].filter(n => n.getBoundingClientRect().height > 0).map(n => ({ text: n.innerText, tag: n.tagName, font: getComputedStyle(n).fontSize, line: getComputedStyle(n).lineHeight })),
  26 |       reviewExitPx: root.querySelector('[data-testid="review-workshop-exit"]')!.getBoundingClientRect().top - bottom,
  27 |       overflow: document.documentElement.scrollWidth > innerWidth,
  28 |     };
  29 |   });
  30 |   expect(metrics.text).toBe(row.metrics.text);
  31 |   expect(metrics.controls).toEqual(row.metrics.controls);
  32 |   // Baseline was captured in Chromium; native font serialization is checked in
  33 |   // that engine. Every engine retains the exact same DOM/style font rules.
  34 |   if (info.project.name === 'chromium') expect(metrics.typography).toEqual(row.metrics.typography);
  35 |   expect(metrics.overflow).toBe(false);
  36 |   const exit = metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  37 |   const oldExit = row.metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  38 |   // Independent source-bound baseline; never move a marker to satisfy travel.
  39 |   if (info.project.name === 'chromium') {
  40 |     expect(exit.gap).toBeLessThanOrEqual(oldExit.gap * .92);
> 41 |     expect(metrics.reviewExitPx).toBeLessThanOrEqual(row.metrics.reviewExitPx);
     |                                  ^ Error: expect(received).toBeLessThanOrEqual(expected)
  42 |     for (const action of metrics.actions) expect(action.gap).toBeLessThanOrEqual(row.metrics.actions.find(a => a.id === action.id)!.gap);
  43 |   }
  44 |   for (const action of metrics.actions) if (!action.disabled) expect(action.height).toBeGreaterThanOrEqual(44);
  45 |   await expect(page.getByTestId('goal')).toBeInViewport();
  46 |   // Original controls, native tab order and actual same keyboard helper:
  47 |   // no new Tab stops, duplicated commits, hidden terms or gesture interceptor.
  48 |   for (const kit of FIELD_KITS) {
  49 |     const review = page.getByTestId(`review-purchase-${kit.id}`), purchase = page.getByTestId(`choice-buy-${kit.id}`);
  50 |     if (await review.isEnabled()) {
  51 |       await keyboardActivate(page, review); await expect(purchase).toBeFocused(); await expect(purchase.locator('.label')).toBeInViewport();
  52 |       expect(await saved()).toBe(before);
  53 |     } else await expect(purchase).toBeDisabled();
  54 |   }
  55 |   await keyboardActivate(page, page.getByTestId('review-workshop-exit'));
  56 |   await expect(page.getByTestId('choice-leave-workshop')).toBeFocused();
  57 |   expect(await saved()).toBe(before);
  58 |   expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
  59 |   const choice = presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.enabled && c.id.startsWith('buy-')) ?? presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.id === 'leave-workshop')!;
  60 |   await keyboardActivate(page, page.getByTestId(`choice-${choice.id}`));
  61 |   const expected = commitChoice(row.state as GameState, choice).state;
  62 |   await expect.poll(async () => JSON.parse((await saved())!)).toEqual(expected);
  63 |   await page.reload(); await page.getByTestId('continue-run').click(); expect(JSON.parse((await saved())!)).toEqual(expected);
  64 |   await info.attach('workshop-task', { body: JSON.stringify({ baseline: row.metrics, current: metrics }), contentType: 'application/json' });
  65 | });
  66 | 
  67 | for (const row of baseline.rows.filter(r => r.creds === 275)) test(`workshop native odds inspections preserve save and normal scroll at${row.width}px`, async ({ page }) => {
  68 |   await page.setViewportSize({ width: row.width, height: 900 });
  69 |   await page.addInitScript(state => {
  70 |     localStorage.setItem('saint-shard-3055-v1', JSON.stringify(state));
  71 |     localStorage.setItem('saint-shard-preferences', JSON.stringify({ sound: false, reading: 'all', artwork: 'none', textStep: 2, contrast: 'high', motion: 'reduce' }));
  72 |   }, row.state);
  73 |   await page.goto('/'); await page.getByTestId('continue-run').click();
  74 |   const before = await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'));
  75 |   for (const kit of FIELD_KITS) {
  76 |     const panel = page.getByTestId(`kit-odds-${kit.id}`);
  77 |     await keyboardActivate(page, panel.locator('summary')); await expect(panel).toHaveAttribute('open', '');
  78 |     await expect(panel.locator('ul')).toBeVisible();
  79 |     expect(await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'))).toBe(before);
  80 |     await keyboardActivate(page, panel.locator('summary'));
  81 |   }
  82 |   const end = await page.evaluate(() => { scrollTo(0, document.documentElement.scrollHeight); return scrollY; });
  83 |   expect(end).toBeGreaterThan(900);
  84 |   await page.evaluate(() => scrollTo(0, 0)); expect(await page.evaluate(() => scrollY)).toBe(0);
  85 |   expect(await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'))).toBe(before);
  86 | });
  87 | 
```