# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: guide.spec.ts >> direct guide at 390px/full has accessible reading and truthful city art
- Location: tests/guide.spec.ts:31:85

# Error details

```
Error: locator.evaluate: Invalid image request.
```

# Page snapshot

```yaml
- generic [active] [ref=e1]:
  - generic [ref=e2]:
    - link "Skip to the field guide" [ref=e3] [cursor=pointer]:
      - /url: "#guide-reading"
    - banner [ref=e4]:
      - link "Saint Shard Kite City · 3055" [ref=e5] [cursor=pointer]:
        - /url: /
        - text: Saint Shard
        - generic [ref=e6]: Kite City · 3055
      - generic [ref=e7]:
        - link "Back to main page" [ref=e8] [cursor=pointer]:
          - /url: /
        - button "Settings" [ref=e9] [cursor=pointer]
    - main [ref=e10]:
      - generic [ref=e11]:
        - paragraph [ref=e12]: Before you take the stool
        - heading "A runner’s field guide" [level=1] [ref=e13]
        - region [ref=e14]:
          - heading "Play in four steps" [level=2] [ref=e15]
          - list [ref=e16]:
            - listitem [ref=e17]:
              - strong [ref=e18]: Read.
              - text: Follow the visible goal and read the scene.
            - listitem [ref=e19]:
              - strong [ref=e20]: Choose.
              - text: Selecting an option commits it.
            - listitem [ref=e21]:
              - strong [ref=e22]: Check.
              - text: Review odds and costs before rolling 1d10.
            - listitem [ref=e23]:
              - strong [ref=e24]: Return.
              - text: Progress saves in this browser; export a backup in Saves.
        - navigation "Field guide chapters" [ref=e25]:
          - link "Enter the city" [ref=e26] [cursor=pointer]:
            - /url: "#guide-city"
          - link "Your first run" [ref=e27] [cursor=pointer]:
            - /url: "#guide-first-run"
          - link "Choices & dice" [ref=e28] [cursor=pointer]:
            - /url: "#guide-checks"
          - link "Keep your word" [ref=e29] [cursor=pointer]:
            - /url: "#guide-memory"
          - link "Controls & saves" [ref=e30] [cursor=pointer]:
            - /url: "#guide-controls"
        - paragraph [ref=e31]: "Later in the week, earned training opens specialist procedures at the canal filing bench. Matching equipment changes exposure, effort or a voluntary bargain; it does not grant another skill. Compare before committing: reading is free, but preparation and submission use saved depot actions. A review reference confirms intake, never source truth or witness permission."
        - paragraph [ref=e32]: Some conversations offer Scene and Detail artwork views. You can inspect either without advancing the words, interrupting a voice or spending an action. Artwork remains optional.
        - paragraph [ref=e33]: The rain is already here. The offer can wait until you know how to listen.
        - paragraph [ref=e34]: Welcome to Saint Shard, a solo story RPG. Read, choose and carry the consequences into the next conversation. This guide introduces the city and the rules while leaving the job’s discoveries for your run.
        - generic [ref=e35]:
          - button "Play menu music" [ref=e36] [cursor=pointer]
          - paragraph [ref=e37]: Under the Awning · menu theme
      - 'figure "Kite City · before midnight View artwork: Kite City · before midnight" [ref=e38]':
        - img "An amber noodle stall shelters a rainy walkway beneath the city's immense dome." [ref=e41]
        - generic [ref=e42]:
          - generic [ref=e43]: Kite City · before midnight
          - 'button "View artwork: Kite City · before midnight" [ref=e44] [cursor=pointer]': View artwork
      - region [ref=e45]:
        - paragraph [ref=e46]: 01 · Beneath the dome
        - heading "Enter Kite City" [level=2] [ref=e47]
        - generic [ref=e48]:
          - heading "A city under glass" [level=3] [ref=e49]
          - paragraph [ref=e50]: It is 3055. Rain runs down the inside of Kite City’s dome. Helion’s towers stay dry above the walkways; below them, people keep stalls, clinics and households going with work the towers rarely see.
        - generic [ref=e51]:
          - heading "An hour you can hold" [level=3] [ref=e52]
          - paragraph [ref=e53]: "Glass Chapel offers memory editing: pay to leave an hour behind. Its original survives in a sliver of glass called a shard. An hour can carry an argument, a regret or something someone wants kept out of circulation. Owning the glass and deciding whose words may leave it are different responsibilities."
        - generic [ref=e54]:
          - heading "You are a runner" [level=3] [ref=e55]
          - paragraph [ref=e56]: You carry parcels, open doors and find things people would rather lose. Tonight, Quill has called you to his noodle stall in Ward Four. You need work. You have not accepted his offer. The reasons you bring to the meeting are yours to choose.
        - heading "The people and institutions around you" [level=3] [ref=e57]
        - generic [ref=e58]:
          - generic [ref=e59]:
            - heading "Quill · the broker" [level=4] [ref=e60]
            - paragraph [ref=e61]: A stall, an advance and a job. Read the terms before treating a warm welcome as friendship.
          - generic [ref=e62]:
            - heading "Lumen · Glass Chapel" [level=4] [ref=e63]
            - paragraph [ref=e64]: The Chapel’s nurse works among chairs, patients and memory machinery. Care takes work; each person still gets to set their own terms.
          - generic [ref=e65]:
            - heading "Helion · the Spire" [level=4] [ref=e66]
            - paragraph [ref=e67]: The tower’s offices run on badges, contracts and records. An old clearance can open a door while leaving your name in a file.
          - generic [ref=e68]:
            - heading "The wards · your neighbors" [level=4] [ref=e69]
            - paragraph [ref=e70]: Families, couriers and repair crews live under the leaks. Their trust grows through what you actually do and remember.
        - paragraph [ref=e71]: Listen for who owns an hour, who witnessed an event and who has agreed to be quoted. Those questions will matter when someone offers you a price.
      - region [ref=e72]:
        - paragraph [ref=e73]: 02 · Find your footing
        - heading "Your first run" [level=2] [ref=e74]
        - list [ref=e75]:
          - listitem [ref=e76]:
            - strong [ref=e77]: Choose New run on the main page.
            - text: Give your runner a street handle. A given name is optional.
          - listitem [ref=e78]:
            - strong [ref=e79]: Choose your origin.
            - text: It gives you starting stats, money and a familiar way through a check.
          - listitem [ref=e80]:
            - strong [ref=e81]: Choose a complication and spend two stat points.
            - text: Read the benefit and cost. Each stat has a cap of five.
          - listitem [ref=e82]:
            - strong [ref=e83]: Take the stool and begin the prologue.
            - text: Follow the goal beneath the location. The opening lets you decide why you came for work before you hear Quill’s offer.
        - generic [ref=e84]:
          - generic [ref=e85]:
            - heading "Gutterwire" [level=3] [ref=e86]
            - paragraph [ref=e87]: Raised under the leaks. You can smell a squad car and a lie at the same range.
            - paragraph [ref=e88]: Nerve checks +1. You count exits before you count threats. Starts with 60 creds, before your complication.
          - generic [ref=e89]:
            - heading "Spire Exile" [level=3] [ref=e90]
            - paragraph [ref=e91]: You wore a Helion badge until the badge stopped wearing you.
            - paragraph [ref=e92]: Chrome checks +1. Some doors still remember your old name. Starts with 100 creds, before your complication.
          - generic [ref=e93]:
            - heading "Dustline" [level=3] [ref=e94]
            - paragraph [ref=e95]: Courier from the flats. The dome is a rumor you decided to invoice.
            - paragraph [ref=e96]: Ghost checks +1. You were finding ways around walls before this dome. Starts with 40 creds, before your complication.
        - paragraph [ref=e97]: "Creds are your money: fares, tools and paid help all draw on the same chip. You can read at your own pace. The whole scene appears by default; paragraph pacing is available in Settings. The game tells you when a job has a limited number of actions. Reading time spends no action."
      - region [ref=e98]:
        - paragraph [ref=e99]: 03 · Read the door
        - heading "Choices and dice" [level=2] [ref=e100]
        - paragraph [ref=e101]: A plain choice takes effect when you select it. A choice with a check opens its difficulty, modifiers, odds and possible costs first. You can go Back before rolling. After a roll, Continue commits its outcome. A saved roll stays the same after a reload.
        - generic [ref=e102]:
          - generic [ref=e103]:
            - heading "Chrome" [level=3] [ref=e104]
            - paragraph [ref=e105]: Machines, locks, and old corporate handshakes.
          - generic [ref=e106]:
            - heading "Nerve" [level=3] [ref=e107]
            - paragraph [ref=e108]: Violence, steadiness, and staying in your body.
          - generic [ref=e109]:
            - heading "Face" [level=3] [ref=e110]
            - paragraph [ref=e111]: Lies, bargains, and the read on a person.
          - generic [ref=e112]:
            - heading "Ghost" [level=3] [ref=e113]
            - paragraph [ref=e114]: Hatches, silence, and the minute nobody counted.
        - paragraph [ref=e115]: Roll one ten-sided die, add the shown stat and modifiers, and meet or beat the difficulty. Preparation, tools and favors can open different approaches. Read each option’s details before spending money, effort or trust.
        - region [ref=e116]:
          - heading "Practice a check" [level=3] [ref=e117]
          - paragraph [ref=e118]:
            - text: A fictional service hatch needs
            - strong [ref=e119]: difficulty 8
            - text: . Your example runner has
            - strong [ref=e120]: Nerve 3
            - text: ", no modifiers and"
            - strong [ref=e121]: Strain 2
            - text: . Choose a die face to see the result.
          - generic [ref=e122]:
            - button "Show a 4" [ref=e123] [cursor=pointer]
            - button "Show a 5" [ref=e124] [cursor=pointer]
            - button "Show a 10" [ref=e125] [cursor=pointer]
            - button "Show a 1" [ref=e126] [cursor=pointer]
          - status [ref=e127]:
            - paragraph [ref=e128]: Your first example is ready. This practice never changes your runner, saved die or progress.
        - heading "Keep an eye on Strain" [level=3] [ref=e129]
        - paragraph [ref=e130]: You have five pips. Difficult work and failed checks can raise Strain; some choices ease it. At five, a bad outcome inside Glass Chapel can put you in the chair. The game warns you when the chair is close. Read the cost before pushing through another door.
        - paragraph [ref=e131]: A miss can change the route, the price or who notices you. Read the next scene for recovery options. Some jobs allow one attempt; reloading does not turn the recorded die into a new chance.
      - region [ref=e132]:
        - paragraph [ref=e133]: 04 · Carry what you know
        - heading "Keep your word" [level=2] [ref=e134]
        - paragraph [ref=e135]: The journal keeps clues, claims and promises with their sources. The commitments panel shows what still needs your attention. Use the character sheet and, when available, Consult acquired sources to revisit what you actually learned.
        - paragraph [ref=e136]: In the notebook, Build a Ward Nine case connects acquired sources to a claim. Test the links, correct unsupported support and carry the tested account into archive work or a hearing. A case draft grants no evidence or permission.
        - paragraph [ref=e137]: After the archive briefing, the optional Archive mission plan lets you choose a reader or carbon approach and a failure contingency. Saving a plan is free; setup choices spend the shown money, effort or exposure. Staffed recovery keeps a paid ledger and free pause available. Withdrawal closes a failed search as unresolved. A carbon copy never authenticates an issuing key.
        - paragraph [ref=e138]: "After source custody and an acquired cancellation receipt, ask Edda about the depot from the canal. A tested notebook case can lead into this conversation; Edda also reviews the recorded sources directly. Choose what to share and whether to send a public review or a private service query. Kerr responds to what he actually knows, including earlier privacy promises. The depot offers two saved task actions: registration and work, booking and rest, or a separate correction delivery. Reading, conversation, playback and settings spend none. Payment and recovery require completion; pausing preserves the allowance, and closing the week ends unfinished opportunities."
        - list [ref=e139]:
          - listitem [ref=e140]:
            - strong [ref=e141]: Read a source before making a claim.
            - text: A recorded recollection, an official record and independent corroboration can support different things.
          - listitem [ref=e142]:
            - strong [ref=e143]: Check what was completed.
            - text: Accepting a job, arriving at a door and observing its handover are separate events.
          - listitem [ref=e144]:
            - strong [ref=e145]: Ask for the right permission.
            - text: Safe transport, a private recording, future contact and public quotation each have their own terms.
          - listitem [ref=e146]:
            - strong [ref=e147]: Leave room for unfinished work.
            - text: A promise can remain open. Return visits let people answer what you actually did.
        - paragraph [ref=e148]: Your run unfolds across The Hour, The Week and The Wall. Optional work and conversations can change what you carry into the next chapter. Follow the visible goal, check your commitments before closing a chapter, and choose the ending your runner can stand behind.
      - region [ref=e149]:
        - paragraph [ref=e150]: 05 · Travel light
        - heading "Controls, comfort and saves" [level=2] [ref=e151]
        - generic [ref=e152]:
          - term [ref=e153]: Touch or mouse
          - definition [ref=e154]: Select a choice or open its check. Sheet, Settings and Saves stay available during play.
          - term [ref=e155]: Keyboard
          - definition [ref=e156]: Tab and Shift+Tab move between controls; Enter activates them. Escape closes a dialog. Number-key choices are enabled by default and can be switched off in Settings.
          - term [ref=e157]: Controller
          - definition [ref=e158]: Enable a standard gamepad in Settings. The D-pad moves between controls, A activates and B closes dialogs.
          - term [ref=e159]: Read and listen
          - definition [ref=e160]: Settings offers larger text, high contrast, reduced motion, paragraph pacing and text-only artwork. Music, ambience, effects and voices have separate sliders. Character dialogue is automatic by default; Stop, Listen and manual dialogue are available.
          - term [ref=e161]: Find your bearings
          - definition [ref=e162]: Open City map from the character sheet to review places introduced in your run. Find locates an available choice so you can review it before acting. Map positions are schematic.
          - term [ref=e163]: Save your place
          - definition [ref=e164]: Progress saves in this browser. Use Saves for three manual slots or export a copy to keep elsewhere. Slot artwork reflects the saved checkpoint; text-only mode keeps its runner and chapter labels. Imports and starting over ask before replacing an active run. If storage is unavailable, the game tells you that progress is session-only.
        - paragraph [ref=e165]: The guide and practice are safe to revisit. They do not accept a job, spend resources, roll a campaign die or replace your save.
        - link "Return to the main page" [ref=e167] [cursor=pointer]:
          - /url: /
        - paragraph [ref=e168]: Corporate violence and memory editing. Original fiction. The city’s discoveries stay in the story.
  - alert [ref=e169]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import AxeBuilder from '@axe-core/playwright';
  3  | import { createCharacter } from '../lib/engine';
  4  | import { installAudioReview, type AudioReview } from '../qa/production/audio-review';
  5  | import { keyboardActivate } from '../qa/production/keyboard';
  6  | const run=createCharacter({handle:'Guide reader',givenName:'Jo',origin:'spire',bonus:{chrome:2,nerve:0,face:0,ghost:0}});
  7  | const audio=(page:import('@playwright/test').Page):Promise<AudioReview>=>page.evaluate(()=>(window as unknown as {audioReview:AudioReview}).audioReview);
  8  | const saved=(page:import('@playwright/test').Page)=>page.evaluate(()=>localStorage.getItem('saint-shard-3055-v1'));
  9  | 
  10 | test('main page guide link, practice, bookmarks and Back preserve the existing campaign and preferences',async({page})=>{
  11 |   await page.addInitScript(run=>{
  12 |     if(!localStorage.getItem('saint-shard-3055-v1'))localStorage.setItem('saint-shard-3055-v1',JSON.stringify(run));
  13 |     localStorage.setItem('saint-shard-preferences',JSON.stringify({sound:false,reading:'paragraph',autoVoices:false}));
  14 |   },run);
  15 |   await page.goto('/');const before=await saved(page);
  16 |   await keyboardActivate(page,page.getByTestId('guide-link'));await expect(page).toHaveURL(/\/guide$/);
  17 |   await expect(page.getByRole('heading',{name:'A runner’s field guide',exact:true})).toBeFocused();
  18 |   await expect(page.getByRole('navigation',{name:'Field guide chapters'})).toBeVisible();
  19 |   for(const [face,total,label] of [[4,7,'Miss.'],[5,8,'Success.'],[10,13,'from 2 to 1'],[1,4,'from 2 to 3']] as const){
  20 |     await keyboardActivate(page,page.getByRole('button',{name:`Show a ${face}`,exact:true}));
  21 |     await expect(page.getByTestId('guide-result')).toContainText(`${face} + 3 = ${total}`);await expect(page.getByTestId('guide-result')).toContainText(label);
  22 |     expect(await saved(page)).toBe(before);
  23 |   }
  24 |   await page.reload();await expect(page.getByTestId('guide-screen')).toBeVisible();await expect(page).toHaveTitle('Runner’s Field Guide — Saint Shard');
  25 |   expect(await saved(page)).toBe(before);await expect(page.getByTestId('guide-result')).toContainText('Your first example is ready');
  26 |   await keyboardActivate(page,page.getByTestId('guide-back'));await expect(page).toHaveURL(/\/$/);await expect(page.getByTestId('title-screen')).toBeVisible();
  27 |   expect(await saved(page)).toBe(before);
  28 |   const prefs=await page.evaluate(()=>JSON.parse(localStorage.getItem('saint-shard-preferences')!));expect(prefs.reading).toBe('paragraph');expect(prefs.autoVoices).toBe(false);expect(prefs.sound).toBe(false);
  29 |   await keyboardActivate(page,page.getByTestId('continue-run'));await expect(page.getByTestId('scene-text')).toBeVisible();expect(await saved(page)).toBe(before);
  30 | });
  31 | for(const [width,artwork] of [[390,'full'],[1440,'full'],[320,'none']] as const)test(`direct guide at ${width}px/${artwork} has accessible reading and truthful city art`,async({page})=>{
  32 |   const requests:string[]=[],errors:string[]=[];page.on('pageerror',e=>errors.push(e.message));page.on('request',r=>{if(/\/(art|audio)\//.test(r.url()))requests.push(r.url());});
  33 |   await page.addInitScript(({artwork})=>localStorage.setItem('saint-shard-preferences',JSON.stringify({sound:false,artwork,textStep:2,contrast:'high',motion:'reduce'})),{artwork});
  34 |   await page.setViewportSize({width,height:900});await page.goto('/guide');
  35 |   await expect(page.getByTestId('guide-screen')).toBeVisible();expect(await saved(page)).toBeNull();
  36 |   await expect(page.getByTestId('guide-screen')).toContainText('It is 3055');
  37 |   await expect(page.getByTestId('guide-screen')).not.toContainText('coolant dump');
  38 |   await expect(page.getByTestId('guide-screen')).not.toContainText('Three hundred');
  39 |   if(artwork==='none'){await expect(page.getByTestId('scene-illustration')).toHaveCount(0);expect(requests).toEqual([]);}
> 40 |   else{const image=page.getByTestId('scene-illustration').locator('img');await expect(image).toHaveAttribute('src','/art/opening.jpg');await image.scrollIntoViewIfNeeded();await image.evaluate((image:HTMLImageElement)=>image.decode());}
     |                                                                                                                                                                                         ^ Error: locator.evaluate: Invalid image request.
  41 |   expect(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth)).toBe(true);
  42 |   expect((await new AxeBuilder({page}).withTags(['wcag2a','wcag2aa','wcag21aa']).analyze()).violations).toEqual([]);
  43 |   await keyboardActivate(page,page.getByRole('link',{name:'Choices & dice',exact:true}));await expect(page).toHaveURL(/#guide-checks$/);
  44 |   await expect(page.getByRole('heading',{name:'Choices and dice',exact:true})).toBeInViewport();expect(errors).toEqual([]);
  45 | });
  46 | test('unavailable guide artwork keeps its description, lore and practice usable',async({page})=>{
  47 |   await page.addInitScript(()=>localStorage.setItem('saint-shard-preferences',JSON.stringify({sound:false})));
  48 |   await page.route('**/art/opening*.jpg',r=>r.fulfill({status:404,body:'Unavailable'}));await page.goto('/guide');
  49 |   await expect(page.getByTestId('scene-illustration').locator('.art-unavailable')).toContainText('noodle stall');
  50 |   await keyboardActivate(page,page.getByRole('button',{name:'Show a 5',exact:true}));await expect(page.getByTestId('guide-result')).toContainText('Success.');
  51 |   expect(await saved(page)).toBeNull();
  52 | });
  53 | test('music continues once across guide navigation, and explicit Stop stays respected',async({page})=>{
  54 |   await page.addInitScript(installAudioReview,{});await page.goto('/');
  55 |   await keyboardActivate(page,page.getByTestId('guide-link'));await expect(page).toHaveURL(/\/guide$/);
  56 |   await expect.poll(async()=>(await audio(page)).started.filter(f=>f==='theme-title.flac').length).toBe(1);
  57 |   const before=await saved(page);await keyboardActivate(page,page.getByTestId('guide-back'));
  58 |   await expect(page.getByTestId('title-screen')).toBeVisible();expect((await audio(page)).started.filter(f=>f==='theme-title.flac')).toHaveLength(1);
  59 |   await keyboardActivate(page,page.getByRole('button',{name:'Stop menu music',exact:true}));await expect.poll(async()=>(await audio(page)).liveSources).toBe(0);
  60 |   await keyboardActivate(page,page.getByTestId('guide-link'));await expect(page.getByTestId('guide-screen')).toBeVisible();
  61 |   expect((await audio(page)).started.filter(f=>f==='theme-title.flac')).toHaveLength(1);expect(await saved(page)).toBe(before);
  62 | });
  63 | test('direct guide respects saved mute and pagehide cancels a later theme start',async({page})=>{
  64 |   await page.addInitScript(installAudioReview,{});await page.addInitScript(()=>localStorage.setItem('saint-shard-preferences',JSON.stringify({sound:false})));
  65 |   const requests:string[]=[];page.on('request',r=>{if(r.url().includes('/audio/'))requests.push(r.url());});
  66 |   await page.goto('/guide');await keyboardActivate(page,page.getByRole('button',{name:'Show a 5',exact:true}));expect(requests).toEqual([]);
  67 |   await keyboardActivate(page,page.getByRole('button',{name:'Settings',exact:true}));await keyboardActivate(page,page.getByLabel('Sound enabled',{exact:true}));
  68 |   await keyboardActivate(page,page.getByRole('button',{name:'Done',exact:true}));await expect.poll(async()=>(await audio(page)).liveSources).toBe(1);
  69 |   await page.evaluate(()=>window.dispatchEvent(new Event('pagehide')));await expect.poll(async()=>(await audio(page)).liveSources).toBe(0);
  70 |   await keyboardActivate(page,page.getByRole('button',{name:'Show a 1',exact:true}));expect((await audio(page)).liveSources).toBe(0);
  71 |   await keyboardActivate(page,page.getByRole('button',{name:'Resume menu music',exact:true}));await expect.poll(async()=>(await audio(page)).liveSources).toBe(1);
  72 |   expect(await saved(page)).toBeNull();
  73 | });
  74 | 
```