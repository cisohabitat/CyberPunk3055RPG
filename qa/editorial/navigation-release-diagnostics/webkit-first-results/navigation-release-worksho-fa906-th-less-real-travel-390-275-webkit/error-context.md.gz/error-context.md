# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation-release.spec.ts >> workshop comparison keeps complete terms with less real travel: 390/275
- Location: tests/navigation-release.spec.ts:9:38

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: keyboard.press: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - link "Skip to choices" [ref=e4]:
      - /url: "#choices"
    - banner [ref=e5]:
      - generic [ref=e12]:
        - text: Saint Shard
        - generic [ref=e13]: Kite City 3055
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Strain
          - meter "Strain 1 of 5" [ref=e19]
        - generic [ref=e25]: 275 cr
      - generic [ref=e28]:
        - button "Settings" [ref=e29] [cursor=pointer]
        - button "Saves" [ref=e30] [cursor=pointer]
        - button "Sheet" [ref=e31] [cursor=pointer]
        - button "Abandon" [ref=e32] [cursor=pointer]
    - main [ref=e34]:
      - article [ref=e35]:
        - generic [ref=e36]:
          - figure [ref=e37]:
            - generic "Quill · The broker" [ref=e39]:
              - generic [ref=e40]: Quill
              - generic [ref=e41]: The broker
          - generic [ref=e42]:
            - paragraph [ref=e43]:
              - text: District repair bench
              - generic [ref=e47]: · The Week
            - heading "District repair bench · The Week" [level=1] [ref=e48]
            - paragraph [ref=e49]: The week wants a buyer or a witness.
            - paragraph [ref=e50]: District repair bench · The Week. The week wants a buyer or a witness.
        - status [ref=e51]: Loaded Autosave — The Week · District repair bench
        - generic [ref=e52]:
          - paragraph [ref=e53]: Quill has laid four cases on the repair bench. None is an all-purpose answer. A probe belongs at a reader, a harness under a chair, a desk guide beside a form, and a shroud on a service route.
          - paragraph [ref=e54]: "'One case in this shipment for you,' he says. 'Keep enough for the person on the other end of the job.'"
          - paragraph [ref=e55]: An unregistered clinic room for Nia costs ninety creds. Staffed recovery for you costs forty-five. Tools can improve a route; they reserve no room and buy no person's consent. You can leave the cases and come back before the week closes.
        - complementary "Quill selected dialogue" [ref=e56]:
          - button "Listen to Quill" [disabled] [ref=e57] [cursor=pointer]
          - button "Play all dialogue" [disabled] [ref=e58] [cursor=pointer]
          - status [ref=e59]: Enable Sound and voice volume in Settings to listen.
          - group [ref=e63]:
            - generic "Voice transcript" [ref=e64] [cursor=pointer]
            - option "1. Quill · One case in this shipment for you,"
            - option "2. Quill · Keep enough for the person on the other end of the job." [selected]
        - region [ref=e65]:
          - generic [ref=e66]:
            - heading "Your next move" [level=2] [ref=e67]
            - paragraph [ref=e68]: Selecting an option commits it.
          - complementary "Compare field equipment" [ref=e69]:
            - heading "Compare field equipment" [level=2] [ref=e70]
            - paragraph [ref=e71]:
              - text: One field kit this week ·
              - strong [ref=e72]: 275 creds available
              - text: . Private witness care costs 90; staffed recovery costs 45.
            - paragraph [ref=e73]: "Only the listed checks receive the bonus. Equipment supplies no evidence, safe room, or consent. Cash benchmarks: room 90 + staffed rest 45 = 135; adding private courier dispatch 15 brings the combined cost to 150. These comparisons reserve nothing; earned rooms and other legal methods remain available."
            - paragraph [ref=e74]: Find the purchase choice and review it. No money is spent until you select that choice.
            - link "Review leaving without buying" [ref=e75]:
              - /url: "#campaign-choice-leave-workshop"
            - generic [ref=e76]:
              - generic [ref=e77]:
                - term [ref=e78]: Archive Probe · 140 creds
                - definition [ref=e79]:
                  - text: Works without training this skill.
                  - group [ref=e80]:
                    - generic "Compare current check odds" [ref=e81] [cursor=pointer]
                  - paragraph [ref=e82]:
                    - strong [ref=e83]: "After purchase: 135 creds."
                    - text: Enough cash remains for a room and staffed rest. Adding a private courier would need 15 more.
                  - button "Review Archive Probe purchase" [ref=e85] [cursor=pointer]
                  - button "Buy the Archive Probe." [ref=e87] [cursor=pointer]:
                    - generic [ref=e88]: "1"
                    - generic [ref=e93]:
                      - generic [ref=e94]:
                        - generic [ref=e95]: Details
                        - generic [ref=e96]: 140 creds. +2 to scanner inspection, archive index preparation, receipt authentication, and the depot sensor ramp. One field kit this week; it stays in your inventory.
                      - generic [ref=e97]:
                        - generic [ref=e98]: Changes
                        - generic [ref=e99]: "-140 cr · Gain Archive Probe"
              - generic [ref=e100]:
                - term [ref=e101]: Chair Harness · 120 creds
                - definition [ref=e102]:
                  - text: Your practiced skill has its own methods.
                  - group [ref=e103]:
                    - generic "How the Chair Harness fits your training" [ref=e104] [cursor=pointer]
                  - group [ref=e105]:
                    - generic "Compare current check odds" [ref=e106] [cursor=pointer]
                  - paragraph [ref=e107]:
                    - strong [ref=e108]: "After purchase: 155 creds."
                    - text: Enough cash remains for a room and staffed rest. A private courier also fits that combined budget.
                  - button "Review Chair Harness purchase" [ref=e110] [cursor=pointer]
                  - button "Buy the Chair Harness." [ref=e112] [cursor=pointer]:
                    - generic [ref=e113]: "2"
                    - generic [ref=e118]:
                      - generic [ref=e119]:
                        - generic [ref=e120]: Details
                        - generic [ref=e121]: 120 creds. +2 to chair preparation, physical witness transfer, archive hatch preparation, physical ledger inspection, carrying sealed clinic cards, the shelter valve, and carrying Kerr’s case. A braced chair permits a no-roll transfer; Steady hands avoids its added strain. One field kit this week; it stays in your inventory.
                      - generic [ref=e122]:
                        - generic [ref=e123]: Changes
                        - generic [ref=e124]: "-120 cr · Gain Chair Harness"
              - generic [ref=e125]:
                - term [ref=e126]: Clinic Desk Guide · 100 creds
                - definition [ref=e127]:
                  - text: Works without training this skill.
                  - group [ref=e128]:
                    - generic "Compare current check odds" [ref=e129] [cursor=pointer]
                  - paragraph [ref=e130]:
                    - strong [ref=e131]: "After purchase: 175 creds."
                    - text: Enough cash remains for a room and staffed rest. A private courier also fits that combined budget.
                  - button "Review Clinic Desk Guide purchase" [ref=e133] [cursor=pointer]
                  - button "Buy the Clinic Desk Guide." [ref=e135] [cursor=pointer]:
                    - generic [ref=e136]: "3"
                    - generic [ref=e141]:
                      - generic [ref=e142]:
                        - generic [ref=e143]: Details
                        - generic [ref=e144]: 100 creds. +2 to arranging a volunteer escort, negotiating a checkpoint transfer, private clinic dispatch, and the depot counter. It supplies procedure, not a forged signature. One field kit this week; it stays in your inventory.
                      - generic [ref=e145]:
                        - generic [ref=e146]: Changes
                        - generic [ref=e147]: "-100 cr · Gain Clinic Desk Guide"
              - generic [ref=e148]:
                - term [ref=e149]: Route Shroud · 140 creds
                - definition [ref=e150]:
                  - text: Works without training this skill.
                  - group [ref=e151]:
                    - generic "Compare current check odds" [active] [ref=e152] [cursor=pointer]
                  - paragraph [ref=e153]:
                    - strong [ref=e154]: "After purchase: 135 creds."
                    - text: Enough cash remains for a room and staffed rest. Adding a private courier would need 15 more.
                  - button "Review Route Shroud purchase" [ref=e156] [cursor=pointer]
                  - button "Buy the Route Shroud." [ref=e158] [cursor=pointer]:
                    - generic [ref=e159]: "4"
                    - generic [ref=e164]:
                      - generic [ref=e165]:
                        - generic [ref=e166]: Details
                        - generic [ref=e167]: 140 creds. +2 to patrol scouting, service-hatch witness transfer, archive interval preparation, carbon retrieval, and the depot patrol gap. One field kit this week; it stays in your inventory.
                      - generic [ref=e168]:
                        - generic [ref=e169]: Changes
                        - generic [ref=e170]: "-140 cr · Gain Route Shroud"
          - button "Keep the care budget. Return to the district board." [ref=e171] [cursor=pointer]:
            - generic [ref=e172]: "5"
        - region "Commitments and history" [ref=e177]:
          - region "Current commitments" [ref=e179]:
            - paragraph [ref=e180]:
              - strong [ref=e181]: Next step
              - text: Compare one kit against the money needed for care. Tools improve specific checks, not base stats.
            - group [ref=e184]:
              - generic "Memory commitments · 0/1 complete · 1 open" [ref=e185] [cursor=pointer]
          - region "Choice reference" [ref=e186]:
            - paragraph [ref=e187]: Selecting an option commits it. For a check, review the odds and costs first; Back leaves it unrolled.
```

# Test source

```ts
  1  | import { expect, type Locator, type Page } from "@playwright/test";
  2  | 
  3  | /** QA navigation through actual Tab/Shift+Tab order. No programmatic focus,
  4  |  * pointer clicks, input fills or number shortcuts are used by these helpers. */
  5  | export async function tabTo(page: Page, target: Locator, limit = 240) {
  6  |   await expect(target).toBeVisible();
  7  |   for (let tabs = 0; tabs <= limit; tabs++) {
  8  |     const direction = await target.evaluate(element => {
  9  |       const active = document.activeElement;
  10 |       if (element === active) return "reached";
  11 |       // Go backwards to earlier controls instead of wrapping through browser
  12 |       // chrome, where page-directed synthetic keys cannot reliably return.
  13 |       return active && active !== document.body && Boolean(element.compareDocumentPosition(active) & Node.DOCUMENT_POSITION_FOLLOWING) ? "Shift+Tab" : "Tab";
  14 |     });
  15 |     if (direction === "reached") return tabs;
> 16 |     if (tabs < limit) await page.keyboard.press(direction);
     |                                           ^ Error: keyboard.press: Test timeout of 30000ms exceeded.
  17 |   }
  18 |   throw new Error(`Control not reached after ${limit} Tabs: ${await target.evaluate(element => element.outerHTML.slice(0, 300))}`);
  19 | }
  20 | 
  21 | export async function keyboardActivate(page: Page, target: Locator) {
  22 |   await expect(target).toBeEnabled();
  23 |   const tabs = await tabTo(page, target);
  24 |   const checkbox = await target.evaluate(element => element instanceof HTMLInputElement && element.type === "checkbox");
  25 |   await page.keyboard.press(checkbox ? "Space" : "Enter");
  26 |   return tabs;
  27 | }
  28 | 
  29 | export async function keyboardSelect(page: Page, target: Locator, value: string) {
  30 |   const tabs = await tabTo(page, target);
  31 |   const index = await target.evaluate((element, wanted) => Array.from((element as HTMLSelectElement).options).findIndex(option => option.value === wanted), value);
  32 |   if (index < 0) throw new Error(`Missing select option ${value}`);
  33 |   await page.keyboard.press("Home");
  34 |   for (let i = 0; i < index; i++) await page.keyboard.press("ArrowDown");
  35 |   await page.keyboard.press("Enter");
  36 |   await expect(target).toHaveValue(value);
  37 |   return tabs;
  38 | }
  39 | 
```