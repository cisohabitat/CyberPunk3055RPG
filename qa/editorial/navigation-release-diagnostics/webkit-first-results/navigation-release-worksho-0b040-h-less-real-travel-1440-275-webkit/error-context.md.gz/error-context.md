# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation-release.spec.ts >> workshop comparison keeps complete terms with less real travel: 1440/275
- Location: tests/navigation-release.spec.ts:9:38

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: frame.evaluate: Test timeout of 30000ms exceeded.
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - link "Skip to choices" [ref=e4]:
      - /url: "#choices"
    - banner [ref=e5]:
      - generic [ref=e12]:
        - text: Saint Shard
        - generic [ref=e13]: Kite City 3055
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Strain
          - meter "Strain 1 of 5" [ref=e19]
        - generic [ref=e25]: 275 cr
      - generic [ref=e28]:
        - button "Settings" [ref=e29] [cursor=pointer]
        - button "Saves" [ref=e30] [cursor=pointer]
        - button "Abandon" [ref=e31] [cursor=pointer]
    - generic [ref=e32]:
      - main [ref=e33]:
        - article [ref=e34]:
          - generic [ref=e35]:
            - figure [ref=e36]:
              - generic "Quill · The broker" [ref=e38]:
                - generic [ref=e39]: Quill
                - generic [ref=e40]: The broker
            - generic [ref=e41]:
              - paragraph [ref=e42]:
                - text: District repair bench
                - generic [ref=e46]: · The Week
              - heading "District repair bench · The Week" [level=1] [ref=e47]
              - paragraph [ref=e48]: The week wants a buyer or a witness.
              - paragraph [ref=e49]: District repair bench · The Week. The week wants a buyer or a witness.
          - status [ref=e50]: Loaded Autosave — The Week · District repair bench
          - generic [ref=e51]:
            - paragraph [ref=e52]: Quill has laid four cases on the repair bench. None is an all-purpose answer. A probe belongs at a reader, a harness under a chair, a desk guide beside a form, and a shroud on a service route.
            - paragraph [ref=e53]: "'One case in this shipment for you,' he says. 'Keep enough for the person on the other end of the job.'"
            - paragraph [ref=e54]: An unregistered clinic room for Nia costs ninety creds. Staffed recovery for you costs forty-five. Tools can improve a route; they reserve no room and buy no person's consent. You can leave the cases and come back before the week closes.
          - complementary "Quill selected dialogue" [ref=e55]:
            - button "Listen to Quill" [disabled] [ref=e56] [cursor=pointer]
            - button "Play all dialogue" [disabled] [ref=e57] [cursor=pointer]
            - status [ref=e58]: Enable Sound and voice volume in Settings to listen.
            - group [ref=e62]:
              - generic "Voice transcript" [ref=e63] [cursor=pointer]
              - option "1. Quill · One case in this shipment for you,"
              - option "2. Quill · Keep enough for the person on the other end of the job." [selected]
          - region [ref=e64]:
            - generic [ref=e65]:
              - heading "Your next move" [level=2] [ref=e66]
              - paragraph [ref=e67]: Selecting an option commits it.
            - complementary "Compare field equipment" [ref=e68]:
              - heading "Compare field equipment" [level=2] [ref=e69]
              - paragraph [ref=e70]:
                - text: One field kit this week ·
                - strong [ref=e71]: 275 creds available
                - text: . Private witness care costs 90; staffed recovery costs 45.
              - paragraph [ref=e72]: "Only the listed checks receive the bonus. Equipment supplies no evidence, safe room, or consent. Cash benchmarks: room 90 + staffed rest 45 = 135; adding private courier dispatch 15 brings the combined cost to 150. These comparisons reserve nothing; earned rooms and other legal methods remain available."
              - paragraph [ref=e73]: Find the purchase choice and review it. No money is spent until you select that choice.
              - link "Review leaving without buying" [ref=e74]:
                - /url: "#campaign-choice-leave-workshop"
              - generic [ref=e75]:
                - generic [ref=e76]:
                  - term [ref=e77]: Archive Probe · 140 creds
                  - definition [ref=e78]:
                    - text: Works without training this skill.
                    - group [ref=e79]:
                      - generic "Compare current check odds" [ref=e80] [cursor=pointer]
                    - paragraph [ref=e81]:
                      - strong [ref=e82]: "After purchase: 135 creds."
                      - text: Enough cash remains for a room and staffed rest. Adding a private courier would need 15 more.
                    - button "Review Archive Probe purchase" [ref=e84] [cursor=pointer]
                    - button "Buy the Archive Probe." [ref=e86] [cursor=pointer]:
                      - generic [ref=e87]: "1"
                      - generic [ref=e92]:
                        - generic [ref=e93]:
                          - generic [ref=e94]: Details
                          - generic [ref=e95]: 140 creds. +2 to scanner inspection, archive index preparation, receipt authentication, and the depot sensor ramp. One field kit this week; it stays in your inventory.
                        - generic [ref=e96]:
                          - generic [ref=e97]: Changes
                          - generic [ref=e98]: "-140 cr · Gain Archive Probe"
                - generic [ref=e99]:
                  - term [ref=e100]: Chair Harness · 120 creds
                  - definition [ref=e101]:
                    - text: Your practiced skill has its own methods.
                    - group [ref=e102]:
                      - generic "How the Chair Harness fits your training" [ref=e103] [cursor=pointer]
                    - group [ref=e104]:
                      - generic "Compare current check odds" [ref=e105] [cursor=pointer]
                    - paragraph [ref=e106]:
                      - strong [ref=e107]: "After purchase: 155 creds."
                      - text: Enough cash remains for a room and staffed rest. A private courier also fits that combined budget.
                    - button "Review Chair Harness purchase" [ref=e109] [cursor=pointer]
                    - button "Buy the Chair Harness." [ref=e111] [cursor=pointer]:
                      - generic [ref=e112]: "2"
                      - generic [ref=e117]:
                        - generic [ref=e118]:
                          - generic [ref=e119]: Details
                          - generic [ref=e120]: 120 creds. +2 to chair preparation, physical witness transfer, archive hatch preparation, physical ledger inspection, carrying sealed clinic cards, the shelter valve, and carrying Kerr’s case. A braced chair permits a no-roll transfer; Steady hands avoids its added strain. One field kit this week; it stays in your inventory.
                        - generic [ref=e121]:
                          - generic [ref=e122]: Changes
                          - generic [ref=e123]: "-120 cr · Gain Chair Harness"
                - generic [ref=e124]:
                  - term [ref=e125]: Clinic Desk Guide · 100 creds
                  - definition [ref=e126]:
                    - text: Works without training this skill.
                    - group [ref=e127]:
                      - generic "Compare current check odds" [ref=e128] [cursor=pointer]
                    - paragraph [ref=e129]:
                      - strong [ref=e130]: "After purchase: 175 creds."
                      - text: Enough cash remains for a room and staffed rest. A private courier also fits that combined budget.
                    - button "Review Clinic Desk Guide purchase" [ref=e132] [cursor=pointer]
                    - button "Buy the Clinic Desk Guide." [ref=e134] [cursor=pointer]:
                      - generic [ref=e135]: "3"
                      - generic [ref=e140]:
                        - generic [ref=e141]:
                          - generic [ref=e142]: Details
                          - generic [ref=e143]: 100 creds. +2 to arranging a volunteer escort, negotiating a checkpoint transfer, private clinic dispatch, and the depot counter. It supplies procedure, not a forged signature. One field kit this week; it stays in your inventory.
                        - generic [ref=e144]:
                          - generic [ref=e145]: Changes
                          - generic [ref=e146]: "-100 cr · Gain Clinic Desk Guide"
                - generic [ref=e147]:
                  - term [ref=e148]: Route Shroud · 140 creds
                  - definition [ref=e149]:
                    - text: Works without training this skill.
                    - group [ref=e150]:
                      - generic "Compare current check odds" [ref=e151] [cursor=pointer]
                    - paragraph [ref=e152]:
                      - strong [ref=e153]: "After purchase: 135 creds."
                      - text: Enough cash remains for a room and staffed rest. Adding a private courier would need 15 more.
                    - button "Review Route Shroud purchase" [ref=e155] [cursor=pointer]
                    - button "Buy the Route Shroud." [ref=e157] [cursor=pointer]:
                      - generic [ref=e158]: "4"
                      - generic [ref=e163]:
                        - generic [ref=e164]:
                          - generic [ref=e165]: Details
                          - generic [ref=e166]: 140 creds. +2 to patrol scouting, service-hatch witness transfer, archive interval preparation, carbon retrieval, and the depot patrol gap. One field kit this week; it stays in your inventory.
                        - generic [ref=e167]:
                          - generic [ref=e168]: Changes
                          - generic [ref=e169]: "-140 cr · Gain Route Shroud"
            - button "Keep the care budget. Return to the district board." [active] [ref=e170] [cursor=pointer]:
              - generic [ref=e171]: "5"
          - region "Commitments and history" [ref=e176]:
            - region "Current commitments" [ref=e178]:
              - paragraph [ref=e179]:
                - strong [ref=e180]: Next step
                - text: Compare one kit against the money needed for care. Tools improve specific checks, not base stats.
              - group [ref=e183]:
                - generic "Memory commitments · 0/1 complete · 1 open" [ref=e184] [cursor=pointer]
            - region "Choice reference" [ref=e185]:
              - paragraph [ref=e186]: Selecting an option commits it. For a check, review the odds and costs first; Back leaves it unrolled.
      - complementary "Character sheet" [ref=e187]:
        - generic [ref=e194]:
          - heading "Replay" [level=2] [ref=e195]
          - paragraph [ref=e196]: Dustline · Ada
        - button "City map" [ref=e197] [cursor=pointer]
        - group [ref=e200]:
          - generic "Origin & complication" [ref=e201] [cursor=pointer]
        - group [ref=e202]:
          - generic "People · 5 met" [ref=e203] [cursor=pointer]
        - tablist "Character details" [ref=e204]:
          - tab "stats" [selected] [ref=e205] [cursor=pointer]
          - tab "gear" [ref=e206] [cursor=pointer]
          - tab "journal" [ref=e207] [cursor=pointer]
        - tabpanel "stats" [ref=e208]:
          - paragraph [ref=e209]:
            - strong [ref=e210]: Steady hands
            - text: · Nerve checks +1. Hold an archive hatch for Edda; chair preparation unlocks a physical transfer route.
          - generic [ref=e211]:
            - generic [ref=e212]: Chrome
            - generic [ref=e215]: "2"
          - generic [ref=e218]:
            - generic [ref=e219]: Nerve
            - generic [ref=e222]: "2"
          - generic [ref=e225]:
            - generic [ref=e226]: Face
            - generic [ref=e229]: "1"
          - generic [ref=e232]:
            - generic [ref=e233]: Ghost
            - generic [ref=e236]: "5"
          - group [ref=e239]:
            - generic "How stats work" [ref=e240] [cursor=pointer]
          - heading "Factions" [level=3] [ref=e241]
          - generic [ref=e242]:
            - generic [ref=e243]: Quill
            - generic [ref=e246]: "3"
          - generic [ref=e249]:
            - generic [ref=e250]: Lumen
            - generic [ref=e253]: "2"
          - generic [ref=e256]:
            - generic [ref=e257]: Helion
            - generic [ref=e260]: "4"
          - generic [ref=e263]:
            - generic [ref=e264]: The wards
            - generic [ref=e267]: "1"
          - group [ref=e270]:
            - generic "How factions affect checks" [ref=e271] [cursor=pointer]
          - group [ref=e272]:
            - generic "What you did · 6 recent" [ref=e273] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import AxeBuilder from '@axe-core/playwright';
  3  | import baseline from '../qa/editorial/navigation-release-layout-baseline.json';
  4  | import { keyboardActivate } from '../qa/production/keyboard';
  5  | import type { GameState } from '../lib/types';
  6  | import { FIELD_KITS } from '../lib/loadout';
  7  | import { commitChoice, getScene, presentChoices } from '../lib/engine';
  8  | 
  9  | for (const row of baseline.rows) test(`workshop comparison keeps complete terms with less real travel: ${row.width}/${row.creds}`, async ({ page }, info) => {
  10 |   await page.setViewportSize({ width: row.width, height: 900 });
  11 |   await page.addInitScript(state => {
  12 |     if (!localStorage.getItem('saint-shard-3055-v1')) localStorage.setItem('saint-shard-3055-v1', JSON.stringify(state));
  13 |     localStorage.setItem('saint-shard-preferences', JSON.stringify({ sound: false, reading: 'all', artwork: 'none', textStep: 2, contrast: 'high', motion: 'reduce' }));
  14 |   }, row.state);
  15 |   await page.goto('/'); await page.getByTestId('continue-run').click(); await page.evaluate(() => document.fonts.ready);
  16 |   const saved = () => page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'));
  17 |   const before = await saved();
  18 |   const metrics = await page.getByTestId('scene').evaluate(root => {
  19 |     const bottom = root.querySelector('[data-testid="scene-text"]')!.getBoundingClientRect().bottom;
  20 |     const controls = [...root.querySelectorAll<HTMLElement>('button,a,summary,input,select')].filter(n => n.getBoundingClientRect().height > 0);
  21 |     return {
  22 |       text: (root as HTMLElement).innerText,
  23 |       controls: controls.map(n => ({ tag: n.tagName, id: n.dataset.testid || n.id, text: n.innerText, disabled: n.hasAttribute('disabled') })),
  24 |       actions: controls.filter(n => n.dataset.testid?.startsWith('choice-')).map(n => ({ id: n.dataset.testid, gap: n.getBoundingClientRect().top - bottom, height: n.getBoundingClientRect().height, disabled: n.hasAttribute('disabled') })),
  25 |       typography: [...root.querySelectorAll<HTMLElement>('p,dt,h2,h3,button,summary')].filter(n => n.getBoundingClientRect().height > 0).map(n => ({ text: n.innerText, tag: n.tagName, font: getComputedStyle(n).fontSize, line: getComputedStyle(n).lineHeight })),
  26 |       reviewExitPx: root.querySelector('[data-testid="review-workshop-exit"]')!.getBoundingClientRect().top - bottom,
  27 |       overflow: document.documentElement.scrollWidth > innerWidth,
  28 |     };
  29 |   });
  30 |   expect(metrics.text).toBe(row.metrics.text);
  31 |   expect(metrics.controls).toEqual(row.metrics.controls);
  32 |   // Baseline was captured in Chromium; native font serialization is checked in
  33 |   // that engine. Every engine retains the exact same DOM/style font rules.
  34 |   if (info.project.name === 'chromium') expect(metrics.typography).toEqual(row.metrics.typography);
  35 |   expect(metrics.overflow).toBe(false);
  36 |   const exit = metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  37 |   const oldExit = row.metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  38 |   // Independent source-bound baseline; never move a marker to satisfy travel.
  39 |   if (info.project.name === 'chromium') {
  40 |     expect(exit.gap).toBeLessThanOrEqual(oldExit.gap * .92);
  41 |     expect(metrics.reviewExitPx).toBeLessThanOrEqual(row.metrics.reviewExitPx);
  42 |     for (const action of metrics.actions) expect(action.gap).toBeLessThanOrEqual(row.metrics.actions.find(a => a.id === action.id)!.gap);
  43 |   }
  44 |   for (const action of metrics.actions) if (!action.disabled) expect(action.height).toBeGreaterThanOrEqual(44);
  45 |   await expect(page.getByTestId('goal')).toBeInViewport();
  46 |   // Original controls, native tab order and actual same keyboard helper:
  47 |   // no new Tab stops, duplicated commits, hidden terms or gesture interceptor.
  48 |   for (const kit of FIELD_KITS) {
  49 |     const review = page.getByTestId(`review-purchase-${kit.id}`), purchase = page.getByTestId(`choice-buy-${kit.id}`);
  50 |     if (await review.isEnabled()) {
  51 |       await keyboardActivate(page, review); await expect(purchase).toBeFocused(); await expect(purchase.locator('.label')).toBeInViewport();
  52 |       expect(await saved()).toBe(before);
  53 |     } else await expect(purchase).toBeDisabled();
  54 |     await keyboardActivate(page, page.getByTestId(`kit-odds-${kit.id}`).locator('summary'));
  55 |     await expect(page.getByTestId(`kit-odds-${kit.id}`)).toHaveAttribute('open', '');
  56 |     expect(await saved()).toBe(before);
  57 |     await keyboardActivate(page, page.getByTestId(`kit-odds-${kit.id}`).locator('summary'));
  58 |   }
  59 |   await keyboardActivate(page, page.getByTestId('review-workshop-exit'));
  60 |   await expect(page.getByTestId('choice-leave-workshop')).toBeFocused();
  61 |   expect(await saved()).toBe(before);
> 62 |   expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
     |           ^ Error: frame.evaluate: Test timeout of 30000ms exceeded.
  63 |   const choice = presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.enabled && c.id.startsWith('buy-')) ?? presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.id === 'leave-workshop')!;
  64 |   await keyboardActivate(page, page.getByTestId(`choice-${choice.id}`));
  65 |   const expected = commitChoice(row.state as GameState, choice).state;
  66 |   await expect.poll(async () => JSON.parse((await saved())!)).toEqual(expected);
  67 |   await page.reload(); await page.getByTestId('continue-run').click(); expect(JSON.parse((await saved())!)).toEqual(expected);
  68 |   await info.attach('workshop-task', { body: JSON.stringify({ baseline: row.metrics, current: metrics }), contentType: 'application/json' });
  69 | });
  70 | 
```