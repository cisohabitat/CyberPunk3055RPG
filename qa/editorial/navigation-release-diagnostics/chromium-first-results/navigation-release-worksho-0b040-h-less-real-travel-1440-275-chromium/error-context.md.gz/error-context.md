# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: navigation-release.spec.ts >> workshop comparison keeps complete terms with less real travel: 1440/275
- Location: tests/navigation-release.spec.ts:9:38

# Error details

```
Error: Test timeout of 30000ms exceeded
```

# Page snapshot

```yaml
- generic [ref=e1]:
  - alert [ref=e2]
  - generic [ref=e3]:
    - link "Skip to choices" [ref=e4] [cursor=pointer]:
      - /url: "#choices"
    - banner [ref=e5]:
      - generic [ref=e12]:
        - text: Saint Shard
        - generic [ref=e13]: Kite City 3055
      - generic [ref=e14]:
        - generic [ref=e15]:
          - generic [ref=e16]: Strain
          - meter "Strain 1 of 5" [ref=e19]
        - generic [ref=e25]:
          - text: 135 cr
          - 'generic "Last choice: Creds -140" [ref=e28]': "-140"
      - generic [ref=e29]:
        - button "Settings" [ref=e30] [cursor=pointer]
        - button "Saves" [ref=e31] [cursor=pointer]
        - button "Abandon" [ref=e32] [cursor=pointer]
    - generic [ref=e33]:
      - main [ref=e34]:
        - article [active] [ref=e35]:
          - generic [ref=e36]:
            - figure [ref=e37]:
              - generic "Replay · Dustline" [ref=e39]:
                - generic [ref=e40]: Replay
                - generic [ref=e41]: Dustline
            - generic [ref=e42]:
              - paragraph [ref=e43]:
                - text: District board, Ward Four
                - generic [ref=e47]: · The Week
              - heading "District board, Ward Four · The Week" [level=1] [ref=e48]
              - paragraph [ref=e49]: The week wants a buyer or a witness.
              - paragraph [ref=e50]: District board, Ward Four · The Week. The week wants a buyer or a witness.
              - paragraph [ref=e51]: "-140 cr · Gained Archive Probe"
          - generic [ref=e52]:
            - paragraph [ref=e53]: Back under the cracked board, you find the calls still face up. Kerr in Ward Four. Lumen at Glass Chapel if she is calling. Helion if it wants the hour.
            - paragraph [ref=e54]: The work you accepted or refused stays in your record. It does not answer this week's question for you.
          - region "Current commitments" [ref=e56]:
            - paragraph [ref=e57]:
              - strong [ref=e58]: Next step
              - text: Answer a district call. Your old contact also offers an optional origin favor.
            - group [ref=e61]:
              - generic "Memory commitments · 0/1 complete · 1 open" [ref=e62] [cursor=pointer]
          - group [ref=e63]:
            - status [ref=e65] [cursor=pointer]: Last choice · 3 updates
          - region [ref=e66]:
            - generic [ref=e67]:
              - heading "Your next move" [level=2] [ref=e68]
              - paragraph [ref=e69]: Selecting an option commits it. For a check, review the odds and costs first; Back leaves it unrolled.
              - paragraph [ref=e70]:
                - generic [ref=e71]: Action
                - generic [ref=e74]: Move on
            - button "Call the contact who knew you before this job." [ref=e77] [cursor=pointer]:
              - generic [ref=e78]: "1"
              - generic [ref=e84]:
                - generic [ref=e85]: Details
                - generic [ref=e86]: An origin-specific favor can earn a shelter, receiver, or freight clearance.
            - button "Ward Four" [ref=e87] [cursor=pointer]:
              - generic [ref=e88]: "2"
              - generic [ref=e94]:
                - generic [ref=e95]: Details
                - generic: Kerr is still counting.
            - button "Glass Chapel" [ref=e96] [cursor=pointer]:
              - generic [ref=e97]: "3"
              - generic [ref=e103]:
                - generic [ref=e104]: Details
                - generic: Lumen called the marker in.
            - button "Helion Spire" [ref=e105] [cursor=pointer]:
              - generic [ref=e106]: "4"
              - generic [ref=e112]:
                - generic [ref=e113]: Details
                - generic: A dry coat wants the rest of the hour.
      - complementary "Character sheet" [ref=e114]:
        - generic [ref=e121]:
          - heading "Replay" [level=2] [ref=e122]
          - paragraph [ref=e123]: Dustline · Ada
        - button "City map" [ref=e124] [cursor=pointer]
        - group [ref=e127]:
          - generic "Origin & complication" [ref=e128] [cursor=pointer]
        - group [ref=e129]:
          - generic "People · 5 met" [ref=e130] [cursor=pointer]
        - tablist "Character details" [ref=e131]:
          - tab "stats" [selected] [ref=e132] [cursor=pointer]
          - tab "gear" [ref=e133] [cursor=pointer]
          - tab "journal" [ref=e134] [cursor=pointer]
        - tabpanel "stats" [ref=e135]:
          - paragraph [ref=e136]:
            - strong [ref=e137]: Steady hands
            - text: · Nerve checks +1. Hold an archive hatch for Edda; chair preparation unlocks a physical transfer route.
          - generic [ref=e138]:
            - generic [ref=e139]: Chrome
            - generic [ref=e142]: "2"
          - generic [ref=e145]:
            - generic [ref=e146]: Nerve
            - generic [ref=e149]: "2"
          - generic [ref=e152]:
            - generic [ref=e153]: Face
            - generic [ref=e156]: "1"
          - generic [ref=e159]:
            - generic [ref=e160]: Ghost
            - generic [ref=e163]: "5"
          - group [ref=e166]:
            - generic "How stats work" [ref=e167] [cursor=pointer]
          - heading "Factions" [level=3] [ref=e168]
          - generic [ref=e169]:
            - generic [ref=e170]: Quill
            - generic [ref=e173]: "3"
          - generic [ref=e176]:
            - generic [ref=e177]: Lumen
            - generic [ref=e180]: "2"
          - generic [ref=e183]:
            - generic [ref=e184]: Helion
            - generic [ref=e187]: "4"
          - generic [ref=e190]:
            - generic [ref=e191]: The wards
            - generic [ref=e194]: "1"
          - group [ref=e197]:
            - generic "How factions affect checks" [ref=e198] [cursor=pointer]
          - group [ref=e199]:
            - generic "What you did · 6 recent" [ref=e200] [cursor=pointer]
```

# Test source

```ts
  1  | import { test, expect } from '@playwright/test';
  2  | import AxeBuilder from '@axe-core/playwright';
  3  | import baseline from '../qa/editorial/navigation-release-layout-baseline.json';
  4  | import { keyboardActivate } from '../qa/production/keyboard';
  5  | import type { GameState } from '../lib/types';
  6  | import { FIELD_KITS } from '../lib/loadout';
  7  | import { commitChoice, getScene, presentChoices } from '../lib/engine';
  8  | 
  9  | for (const row of baseline.rows) test(`workshop comparison keeps complete terms with less real travel: ${row.width}/${row.creds}`, async ({ page }, info) => {
  10 |   await page.setViewportSize({ width: row.width, height: 900 });
  11 |   await page.addInitScript(state => {
  12 |     if (!localStorage.getItem('saint-shard-3055-v1')) localStorage.setItem('saint-shard-3055-v1', JSON.stringify(state));
  13 |     localStorage.setItem('saint-shard-preferences', JSON.stringify({ sound: false, reading: 'all', artwork: 'none', textStep: 2, contrast: 'high', motion: 'reduce' }));
  14 |   }, row.state);
  15 |   await page.goto('/'); await page.getByTestId('continue-run').click(); await page.evaluate(() => document.fonts.ready);
  16 |   const saved = () => page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'));
  17 |   const before = await saved();
  18 |   const metrics = await page.getByTestId('scene').evaluate(root => {
  19 |     const bottom = root.querySelector('[data-testid="scene-text"]')!.getBoundingClientRect().bottom;
  20 |     const controls = [...root.querySelectorAll<HTMLElement>('button,a,summary,input,select')].filter(n => n.getBoundingClientRect().height > 0);
  21 |     return {
  22 |       text: (root as HTMLElement).innerText,
  23 |       controls: controls.map(n => ({ tag: n.tagName, id: n.dataset.testid || n.id, text: n.innerText, disabled: n.hasAttribute('disabled') })),
  24 |       actions: controls.filter(n => n.dataset.testid?.startsWith('choice-')).map(n => ({ id: n.dataset.testid, gap: n.getBoundingClientRect().top - bottom, height: n.getBoundingClientRect().height, disabled: n.hasAttribute('disabled') })),
  25 |       typography: [...root.querySelectorAll<HTMLElement>('p,dt,h2,h3,button,summary')].filter(n => n.getBoundingClientRect().height > 0).map(n => ({ text: n.innerText, tag: n.tagName, font: getComputedStyle(n).fontSize, line: getComputedStyle(n).lineHeight })),
  26 |       reviewExitPx: root.querySelector('[data-testid="review-workshop-exit"]')!.getBoundingClientRect().top - bottom,
  27 |       overflow: document.documentElement.scrollWidth > innerWidth,
  28 |     };
  29 |   });
  30 |   expect(metrics.text).toBe(row.metrics.text);
  31 |   expect(metrics.controls).toEqual(row.metrics.controls);
  32 |   // Baseline was captured in Chromium; native font serialization is checked in
  33 |   // that engine. Every engine retains the exact same DOM/style font rules.
  34 |   if (info.project.name === 'chromium') expect(metrics.typography).toEqual(row.metrics.typography);
  35 |   expect(metrics.overflow).toBe(false);
  36 |   const exit = metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  37 |   const oldExit = row.metrics.actions.find(a => a.id === 'choice-leave-workshop')!;
  38 |   // Independent source-bound baseline; never move a marker to satisfy travel.
  39 |   if (info.project.name === 'chromium') {
  40 |     expect(exit.gap).toBeLessThanOrEqual(oldExit.gap * .92);
  41 |     expect(metrics.reviewExitPx).toBeLessThanOrEqual(row.metrics.reviewExitPx);
  42 |     for (const action of metrics.actions) expect(action.gap).toBeLessThanOrEqual(row.metrics.actions.find(a => a.id === action.id)!.gap);
  43 |   }
  44 |   for (const action of metrics.actions) if (!action.disabled) expect(action.height).toBeGreaterThanOrEqual(44);
  45 |   await expect(page.getByTestId('goal')).toBeInViewport();
  46 |   // Original controls, native tab order and actual same keyboard helper:
  47 |   // no new Tab stops, duplicated commits, hidden terms or gesture interceptor.
  48 |   for (const kit of FIELD_KITS) {
  49 |     const review = page.getByTestId(`review-purchase-${kit.id}`), purchase = page.getByTestId(`choice-buy-${kit.id}`);
  50 |     if (await review.isEnabled()) {
  51 |       await keyboardActivate(page, review); await expect(purchase).toBeFocused(); await expect(purchase.locator('.label')).toBeInViewport();
  52 |       expect(await saved()).toBe(before);
  53 |     } else await expect(purchase).toBeDisabled();
  54 |   }
  55 |   await keyboardActivate(page, page.getByTestId('review-workshop-exit'));
  56 |   await expect(page.getByTestId('choice-leave-workshop')).toBeFocused();
  57 |   expect(await saved()).toBe(before);
  58 |   expect((await new AxeBuilder({ page }).analyze()).violations).toEqual([]);
  59 |   const choice = presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.enabled && c.id.startsWith('buy-')) ?? presentChoices(row.state as GameState, getScene(row.state.sceneId)).find(c => c.id === 'leave-workshop')!;
  60 |   await keyboardActivate(page, page.getByTestId(`choice-${choice.id}`));
  61 |   const expected = commitChoice(row.state as GameState, choice).state;
  62 |   await expect.poll(async () => JSON.parse((await saved())!)).toEqual(expected);
  63 |   await page.reload(); await page.getByTestId('continue-run').click(); expect(JSON.parse((await saved())!)).toEqual(expected);
  64 |   await info.attach('workshop-task', { body: JSON.stringify({ baseline: row.metrics, current: metrics }), contentType: 'application/json' });
  65 | });
> 66 | 
     |                                                               ^ Error: Test timeout of 30000ms exceeded
  67 | for (const row of baseline.rows.filter(r => r.creds === 275)) test(`workshop native odds inspections preserve save and normal scroll at${row.width}px`, async ({ page }) => {
  68 |   await page.setViewportSize({ width: row.width, height: 900 });
  69 |   await page.addInitScript(state => {
  70 |     localStorage.setItem('saint-shard-3055-v1', JSON.stringify(state));
  71 |     localStorage.setItem('saint-shard-preferences', JSON.stringify({ sound: false, reading: 'all', artwork: 'none', textStep: 2, contrast: 'high', motion: 'reduce' }));
  72 |   }, row.state);
  73 |   await page.goto('/'); await page.getByTestId('continue-run').click();
  74 |   const before = await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'));
  75 |   for (const kit of FIELD_KITS) {
  76 |     const panel = page.getByTestId(`kit-odds-${kit.id}`);
  77 |     await keyboardActivate(page, panel.locator('summary')); await expect(panel).toHaveAttribute('open', '');
  78 |     await expect(panel.locator('ul')).toBeVisible();
  79 |     expect(await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'))).toBe(before);
  80 |     await keyboardActivate(page, panel.locator('summary'));
  81 |   }
  82 |   const end = await page.evaluate(() => { scrollTo(0, document.documentElement.scrollHeight); return scrollY; });
  83 |   expect(end).toBeGreaterThan(900);
  84 |   await page.evaluate(() => scrollTo(0, 0)); expect(await page.evaluate(() => scrollY)).toBe(0);
  85 |   expect(await page.evaluate(() => localStorage.getItem('saint-shard-3055-v1'))).toBe(before);
  86 | });
  87 | 
```